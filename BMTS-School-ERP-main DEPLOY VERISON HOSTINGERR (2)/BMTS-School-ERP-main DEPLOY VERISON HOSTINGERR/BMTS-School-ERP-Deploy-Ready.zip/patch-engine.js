const fs = require('fs');
const path = require('path');

try {
    const clientDir = path.join(__dirname, 'node_modules', '.prisma', 'client');
    if (fs.existsSync(clientDir)) {
        const files = fs.readdirSync(clientDir);
        console.log('Available Prisma engines:', files.filter(f => f.includes('query_engine')));
        
        const rhel11 = path.join(clientDir, 'libquery_engine-rhel-openssl-1.1.x.so.node');
        const debian11 = path.join(clientDir, 'libquery_engine-debian-openssl-1.1.x.so.node');
        
        if (fs.existsSync(rhel11)) {
            fs.copyFileSync(rhel11, debian11);
            console.log('✓ Successfully patched debian query engine with rhel binary for Hostinger CloudLinux');
        }
    }
} catch (err) {
    console.error('Patch engine notice:', err.message);
}
