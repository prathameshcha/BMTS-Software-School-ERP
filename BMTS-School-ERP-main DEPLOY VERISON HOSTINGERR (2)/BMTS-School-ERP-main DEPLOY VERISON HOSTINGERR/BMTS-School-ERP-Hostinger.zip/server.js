// Hostinger entry point
// Load environment variables BEFORE anything else
// This is critical because the compiled server.js imports database.js
// at the top level (before its own dotenv.config() call), and Prisma
// reads DATABASE_URL at import time.
require('dotenv').config();
require('./dist/server.js');