"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
router.get('/', async (req, res, next) => {
    try {
        const { academicYearId } = req.query;
        const where = academicYearId ? { academicYearId: String(academicYearId) } : {};
        const h = await database_js_1.prisma.holiday.findMany({ where, orderBy: { date: 'asc' } });
        res.json({ success: true, data: h });
    }
    catch (err) {
        next(err);
    }
});
router.post('/', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const h = await database_js_1.prisma.holiday.create({ data: { ...req.body, date: new Date(req.body.date) } });
        res.json({ success: true, data: h });
    }
    catch (err) {
        next(err);
    }
});
router.put('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const h = await database_js_1.prisma.holiday.update({
            where: { id: req.params.id },
            data: { ...req.body, date: req.body.date ? new Date(req.body.date) : undefined }
        });
        res.json({ success: true, data: h });
    }
    catch (err) {
        next(err);
    }
});
router.delete('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        await database_js_1.prisma.holiday.delete({ where: { id: req.params.id } });
        res.json({ success: true, message: 'Deleted' });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
