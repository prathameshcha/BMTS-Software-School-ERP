"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
router.get('/', async (req, res, next) => {
    try {
        const rules = await database_js_1.prisma.gradeRule.findMany({ orderBy: { displayOrder: 'asc' } });
        res.json({ success: true, data: rules });
    }
    catch (err) {
        next(err);
    }
});
router.get('/resolve', async (req, res, next) => {
    try {
        const { percentage } = req.query;
        if (percentage === undefined) {
            return res.status(400).json({ success: false, error: 'percentage query parameter is required' });
        }
        const perc = Number(percentage);
        if (isNaN(perc)) {
            return res.status(400).json({ success: false, error: 'percentage must be a valid number' });
        }
        const rule = await database_js_1.prisma.gradeRule.findFirst({
            where: {
                minPercentage: { lte: perc },
                maxPercentage: { gte: perc }
            }
        });
        if (!rule) {
            return res.status(404).json({ success: false, error: 'No grade rule found for this percentage' });
        }
        res.json({ success: true, data: rule });
    }
    catch (err) {
        next(err);
    }
});
router.post('/', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { name, minPercentage, maxPercentage, displayOrder } = req.body;
        if (!name || typeof name !== 'string' || name.trim() === '') {
            return res.status(400).json({ success: false, error: 'name is required and non-empty' });
        }
        if (typeof minPercentage !== 'number' || minPercentage < 0) {
            return res.status(400).json({ success: false, error: 'minPercentage must be a number >= 0' });
        }
        if (typeof maxPercentage !== 'number' || maxPercentage > 100) {
            return res.status(400).json({ success: false, error: 'maxPercentage must be a number <= 100' });
        }
        if (minPercentage >= maxPercentage) {
            return res.status(400).json({ success: false, error: 'minPercentage must be < maxPercentage' });
        }
        const overlapping = await database_js_1.prisma.gradeRule.findFirst({
            where: {
                AND: [
                    { minPercentage: { lte: maxPercentage } },
                    { maxPercentage: { gte: minPercentage } }
                ]
            }
        });
        if (overlapping) {
            return res.status(400).json({ success: false, error: 'Grade rule range overlaps with an existing rule' });
        }
        const r = await database_js_1.prisma.gradeRule.create({
            data: { name: name.trim(), minPercentage, maxPercentage, displayOrder }
        });
        res.json({ success: true, data: r });
    }
    catch (err) {
        next(err);
    }
});
router.put('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { name, minPercentage, maxPercentage, displayOrder } = req.body;
        if (!name || typeof name !== 'string' || name.trim() === '') {
            return res.status(400).json({ success: false, error: 'name is required and non-empty' });
        }
        if (typeof minPercentage !== 'number' || minPercentage < 0) {
            return res.status(400).json({ success: false, error: 'minPercentage must be a number >= 0' });
        }
        if (typeof maxPercentage !== 'number' || maxPercentage > 100) {
            return res.status(400).json({ success: false, error: 'maxPercentage must be a number <= 100' });
        }
        if (minPercentage >= maxPercentage) {
            return res.status(400).json({ success: false, error: 'minPercentage must be < maxPercentage' });
        }
        const overlapping = await database_js_1.prisma.gradeRule.findFirst({
            where: {
                id: { not: req.params.id },
                AND: [
                    { minPercentage: { lte: maxPercentage } },
                    { maxPercentage: { gte: minPercentage } }
                ]
            }
        });
        if (overlapping) {
            return res.status(400).json({ success: false, error: 'Grade rule range overlaps with an existing rule' });
        }
        const r = await database_js_1.prisma.gradeRule.update({
            where: { id: req.params.id },
            data: { name: name.trim(), minPercentage, maxPercentage, displayOrder }
        });
        res.json({ success: true, data: r });
    }
    catch (err) {
        next(err);
    }
});
router.delete('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        await database_js_1.prisma.gradeRule.delete({ where: { id: req.params.id } });
        res.json({ success: true, message: 'Deleted' });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
