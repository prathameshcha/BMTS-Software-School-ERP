"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.JWT_REFRESH_EXPIRY = exports.JWT_EXPIRY = exports.JWT_REFRESH_SECRET = exports.JWT_SECRET = void 0;
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const isProduction = process.env.NODE_ENV === 'production';
if (isProduction && !process.env.JWT_SECRET) {
    throw new Error('FATAL: JWT_SECRET environment variable is required in production.');
}
if (isProduction && !process.env.JWT_REFRESH_SECRET) {
    throw new Error('FATAL: JWT_REFRESH_SECRET environment variable is required in production.');
}
exports.JWT_SECRET = process.env.JWT_SECRET || 'fallback_secret';
exports.JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'fallback_refresh_secret';
exports.JWT_EXPIRY = process.env.JWT_EXPIRY || '15m';
exports.JWT_REFRESH_EXPIRY = process.env.JWT_REFRESH_EXPIRY || '7d';
