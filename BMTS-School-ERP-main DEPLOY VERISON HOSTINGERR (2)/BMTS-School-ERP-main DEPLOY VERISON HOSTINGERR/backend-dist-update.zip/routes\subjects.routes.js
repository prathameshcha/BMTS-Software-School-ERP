"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
router.get('/', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY', 'STUDENT'), async (req, res, next) => {
    try {
        const { classId } = req.query;
        const where = classId ? { classId: String(classId) } : {};
        const subjects = await database_js_1.prisma.subject.findMany({
            where,
            include: {
                class: { select: { id: true, name: true, displayOrder: true } },
            },
            orderBy: [
                { class: { displayOrder: 'asc' } },
                { displayOrder: 'asc' },
            ],
        });
        res.json({ success: true, data: subjects });
    }
    catch (err) {
        next(err);
    }
});
router.post('/', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const { name, code, classId, maxMarks, passingMarks, displayOrder, isActive = true } = req.body;
        const sub = await database_js_1.prisma.subject.create({
            data: {
                name,
                code: code || `${name.slice(0, 4).toUpperCase()}${Math.floor(100 + Math.random() * 900)}`,
                classId,
                maxMarks: maxMarks ? Number(maxMarks) : 100,
                passingMarks: passingMarks ? Number(passingMarks) : 35,
                displayOrder: displayOrder ? Number(displayOrder) : 1,
                isActive: isActive !== false,
            },
            include: {
                class: { select: { id: true, name: true } },
            },
        });
        res.json({ success: true, data: sub });
    }
    catch (err) {
        next(err);
    }
});
router.put('/:id', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const { name, code, classId, maxMarks, passingMarks, displayOrder, isActive } = req.body;
        const updateData = {};
        if (name !== undefined)
            updateData.name = name;
        if (code !== undefined)
            updateData.code = code;
        if (classId !== undefined)
            updateData.classId = classId;
        if (maxMarks !== undefined)
            updateData.maxMarks = Number(maxMarks);
        if (passingMarks !== undefined)
            updateData.passingMarks = Number(passingMarks);
        if (displayOrder !== undefined)
            updateData.displayOrder = Number(displayOrder);
        if (isActive !== undefined)
            updateData.isActive = !!isActive;
        const sub = await database_js_1.prisma.subject.update({
            where: { id: req.params.id },
            data: updateData,
            include: {
                class: { select: { id: true, name: true } },
            },
        });
        res.json({ success: true, data: sub });
    }
    catch (err) {
        next(err);
    }
});
router.delete('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        await database_js_1.prisma.subject.delete({ where: { id: req.params.id } });
        res.json({ success: true, message: 'Subject deleted successfully' });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
