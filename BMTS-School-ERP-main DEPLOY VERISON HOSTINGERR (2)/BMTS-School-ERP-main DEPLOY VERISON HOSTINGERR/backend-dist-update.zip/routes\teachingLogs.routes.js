"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
// GET /api/teaching-logs — List teaching logs with optional filters
router.get('/', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const { classId, divisionId, teacherId, date, startDate, endDate } = req.query;
        const user = req.user;
        const where = {};
        if (classId)
            where.classId = classId;
        if (divisionId)
            where.divisionId = divisionId;
        if (teacherId) {
            where.teacherId = teacherId;
        }
        else if (user.role === 'FACULTY' && !classId) {
            const teacher = await database_js_1.prisma.teacher.findUnique({ where: { userId: user.id } });
            if (teacher)
                where.teacherId = teacher.id;
        }
        if (date) {
            where.date = new Date(date);
        }
        else if (startDate || endDate) {
            where.date = {};
            if (startDate)
                where.date.gte = new Date(startDate);
            if (endDate)
                where.date.lte = new Date(endDate);
        }
        const logs = await database_js_1.prisma.dailyTeachingLog.findMany({
            where,
            include: {
                class: true,
                division: true,
                subject: true,
                teacher: { select: { id: true, name: true, photo: true } },
            },
            orderBy: { date: 'desc' },
        });
        res.json({ success: true, data: logs });
    }
    catch (err) {
        next(err);
    }
});
// GET /api/teaching-logs/by-date — Fetch single log for class, division, and date
router.get('/by-date', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const { classId, divisionId, date } = req.query;
        if (!classId || !divisionId || !date) {
            return res.status(400).json({ success: false, error: 'classId, divisionId, and date are required' });
        }
        const logs = await database_js_1.prisma.dailyTeachingLog.findMany({
            where: {
                classId: classId,
                divisionId: divisionId,
                date: new Date(date),
            },
            include: {
                class: true,
                division: true,
                subject: true,
                teacher: { select: { id: true, name: true, photo: true } },
            },
        });
        res.json({ success: true, data: logs[0] || null });
    }
    catch (err) {
        next(err);
    }
});
// POST /api/teaching-logs — Create or update daily teaching log
router.post('/', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const user = req.user;
        const { classId, divisionId, date, subjectId, topicTaught, homeworkGiven, remarks } = req.body;
        if (!classId || !divisionId || !date || !topicTaught) {
            return res.status(400).json({
                success: false,
                error: 'Class, Division, Date, and Topic Taught are required',
            });
        }
        let teacherId = req.body.teacherId;
        if (user.role === 'FACULTY') {
            const teacher = await database_js_1.prisma.teacher.findUnique({ where: { userId: user.id } });
            if (teacher)
                teacherId = teacher.id;
        }
        if (!teacherId) {
            const firstTeacher = await database_js_1.prisma.teacher.findFirst();
            teacherId = firstTeacher?.id;
        }
        const logDate = new Date(date);
        // Upsert teaching log
        const existing = await database_js_1.prisma.dailyTeachingLog.findFirst({
            where: {
                classId,
                divisionId,
                teacherId,
                date: logDate,
            },
        });
        let result;
        if (existing) {
            result = await database_js_1.prisma.dailyTeachingLog.update({
                where: { id: existing.id },
                data: {
                    subjectId: subjectId || null,
                    topicTaught,
                    homeworkGiven: homeworkGiven || null,
                    remarks: remarks || null,
                },
                include: {
                    class: true,
                    division: true,
                    subject: true,
                    teacher: { select: { id: true, name: true, photo: true } },
                },
            });
        }
        else {
            result = await database_js_1.prisma.dailyTeachingLog.create({
                data: {
                    classId,
                    divisionId,
                    teacherId,
                    date: logDate,
                    subjectId: subjectId || null,
                    topicTaught,
                    homeworkGiven: homeworkGiven || null,
                    remarks: remarks || null,
                },
                include: {
                    class: true,
                    division: true,
                    subject: true,
                    teacher: { select: { id: true, name: true, photo: true } },
                },
            });
        }
        res.json({ success: true, data: result });
    }
    catch (err) {
        next(err);
    }
});
// DELETE /api/teaching-logs/:id
router.delete('/:id', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        await database_js_1.prisma.dailyTeachingLog.delete({
            where: { id: req.params.id },
        });
        res.json({ success: true, message: 'Teaching log deleted successfully' });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
