"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
router.use((0, roleGuard_js_1.authorize)('ADMIN'));
router.get('/', async (req, res, next) => {
    try {
        const admins = await database_js_1.prisma.admin.findMany({
            include: {
                user: { select: { id: true, email: true, username: true, status: true, role: true } }
            },
            orderBy: { createdAt: 'asc' }
        });
        res.json({ success: true, data: admins });
    }
    catch (err) {
        next(err);
    }
});
router.post('/', async (req, res, next) => {
    try {
        const { email, username, password, name, phone } = req.body;
        if (!email || !username || !password || !name) {
            return res.status(400).json({ success: false, error: 'Email, username, password, and name are required' });
        }
        const existingUser = await database_js_1.prisma.user.findFirst({
            where: { OR: [{ email }, { username }] }
        });
        if (existingUser) {
            return res.status(400).json({ success: false, error: 'Email or username already exists' });
        }
        const passwordHash = await bcryptjs_1.default.hash(password, 10);
        const newAdmin = await database_js_1.prisma.user.create({
            data: {
                email,
                username,
                passwordHash,
                role: 'ADMIN',
                status: 'ACTIVE',
                admin: {
                    create: {
                        name,
                        phone: phone || null
                    }
                }
            },
            include: { admin: true }
        });
        res.json({ success: true, data: newAdmin });
    }
    catch (err) {
        next(err);
    }
});
router.put('/:id', async (req, res, next) => {
    try {
        const adminId = req.params.id;
        const { name, phone, email, username, status, password } = req.body;
        const admin = await database_js_1.prisma.admin.findUnique({
            where: { id: adminId },
            include: { user: true }
        });
        if (!admin) {
            return res.status(404).json({ success: false, error: 'Admin not found' });
        }
        if (admin.user.username === 'admin' && status && status !== 'ACTIVE') {
            return res.status(400).json({ success: false, error: 'Cannot deactivate the primary super admin' });
        }
        const updateData = {};
        if (email)
            updateData.email = email;
        if (username)
            updateData.username = username;
        if (status)
            updateData.status = status;
        if (password) {
            updateData.passwordHash = await bcryptjs_1.default.hash(password, 10);
        }
        const updatedUser = await database_js_1.prisma.user.update({
            where: { id: admin.userId },
            data: {
                ...updateData,
                admin: {
                    update: {
                        name: name || admin.name,
                        phone: phone !== undefined ? phone : admin.phone
                    }
                }
            },
            include: { admin: true }
        });
        res.json({ success: true, data: updatedUser });
    }
    catch (err) {
        next(err);
    }
});
router.delete('/:id', async (req, res, next) => {
    try {
        const adminId = req.params.id;
        const admin = await database_js_1.prisma.admin.findUnique({
            where: { id: adminId },
            include: { user: true }
        });
        if (!admin) {
            return res.status(404).json({ success: false, error: 'Admin not found' });
        }
        if (admin.user.username === 'admin') {
            return res.status(400).json({ success: false, error: 'Cannot delete the primary super admin' });
        }
        await database_js_1.prisma.user.delete({
            where: { id: admin.userId }
        });
        res.json({ success: true, message: 'Admin deleted successfully' });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
