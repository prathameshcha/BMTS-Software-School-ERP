"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
router.use((0, roleGuard_js_1.authorize)('ADMIN'));
router.get('/', async (req, res, next) => {
    try {
        const logs = await database_js_1.prisma.auditLog.findMany({
            orderBy: { createdAt: 'desc' },
            take: 50
        });
        res.json({ success: true, data: logs });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
