"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
// Public / Auth read
router.get('/', auth_js_1.authenticateToken, async (req, res, next) => {
    try {
        const { fieldKey, activeOnly } = req.query;
        const where = {};
        if (fieldKey)
            where.fieldKey = String(fieldKey);
        if (activeOnly === 'true')
            where.active = true;
        const remarks = await database_js_1.prisma.remarkBank.findMany({
            where,
            orderBy: { createdAt: 'asc' },
        });
        res.json({ success: true, data: remarks });
    }
    catch (err) {
        next(err);
    }
});
// Admin management routes
router.post('/', auth_js_1.authenticateToken, (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { fieldKey, textEn, textMr } = req.body;
        if (!fieldKey || !textEn) {
            return res.status(400).json({ success: false, error: 'Field key and English text are required' });
        }
        const remark = await database_js_1.prisma.remarkBank.create({
            data: {
                fieldKey,
                textEn,
                textMr: textMr || null,
                active: true,
                createdBy: req.user.id,
            },
        });
        res.json({ success: true, data: remark });
    }
    catch (err) {
        next(err);
    }
});
router.put('/:id', auth_js_1.authenticateToken, (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { textEn, textMr, active } = req.body;
        const remark = await database_js_1.prisma.remarkBank.update({
            where: { id: req.params.id },
            data: {
                ...(textEn !== undefined && { textEn }),
                ...(textMr !== undefined && { textMr }),
                ...(active !== undefined && { active }),
            },
        });
        res.json({ success: true, data: remark });
    }
    catch (err) {
        next(err);
    }
});
router.delete('/:id', auth_js_1.authenticateToken, (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        await database_js_1.prisma.remarkBank.delete({ where: { id: req.params.id } });
        res.json({ success: true, message: 'Remark deleted' });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
