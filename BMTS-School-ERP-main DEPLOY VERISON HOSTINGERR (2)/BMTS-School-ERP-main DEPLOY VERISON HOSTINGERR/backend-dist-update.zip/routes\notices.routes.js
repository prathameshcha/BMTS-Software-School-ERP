"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
router.get('/', async (req, res, next) => {
    try {
        const notices = await database_js_1.prisma.notice.findMany({ orderBy: { publishedAt: 'desc' } });
        res.json({ success: true, data: notices });
    }
    catch (err) {
        next(err);
    }
});
router.post('/', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const { title, content, scope, targetClassId, academicYearId } = req.body;
        const n = await database_js_1.prisma.notice.create({
            data: { title, content, scope, targetClassId, academicYearId, authorId: req.user.id }
        });
        res.json({ success: true, data: n });
    }
    catch (err) {
        next(err);
    }
});
router.put('/:id', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const n = await database_js_1.prisma.notice.update({ where: { id: req.params.id }, data: req.body });
        res.json({ success: true, data: n });
    }
    catch (err) {
        next(err);
    }
});
router.delete('/:id', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        await database_js_1.prisma.notice.delete({ where: { id: req.params.id } });
        res.json({ success: true, message: 'Deleted' });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
