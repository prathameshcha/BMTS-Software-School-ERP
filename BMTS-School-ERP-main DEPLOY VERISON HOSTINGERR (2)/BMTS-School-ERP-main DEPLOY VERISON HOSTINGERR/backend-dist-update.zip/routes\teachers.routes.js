"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
// Faculty self routes
router.get('/me/assignments', (0, roleGuard_js_1.authorize)('FACULTY', 'ADMIN'), async (req, res, next) => {
    try {
        const teacher = await database_js_1.prisma.teacher.findUnique({
            where: { userId: req.user?.id }
        });
        if (!teacher)
            return res.status(404).json({ success: false, error: 'Teacher profile not found' });
        let { academicYearId } = req.query;
        if (!academicYearId) {
            const activeYear = await database_js_1.prisma.academicYear.findFirst({ where: { isActive: true } });
            if (activeYear)
                academicYearId = activeYear.id;
        }
        const assignments = await database_js_1.prisma.teacherAssignment.findMany({
            where: {
                teacherId: teacher.id,
                ...(academicYearId && { academicYearId: String(academicYearId) })
            },
            include: { class: true, division: true, subject: true, academicYear: true }
        });
        res.json({ success: true, data: assignments });
    }
    catch (err) {
        next(err);
    }
});
router.post('/me/assignments', (0, roleGuard_js_1.authorize)('FACULTY', 'ADMIN'), async (req, res, next) => {
    try {
        const teacher = await database_js_1.prisma.teacher.findUnique({
            where: { userId: req.user?.id }
        });
        if (!teacher)
            return res.status(404).json({ success: false, error: 'Teacher profile not found' });
        const { classId, divisionId, subjectId, academicYearId } = req.body;
        const exists = await database_js_1.prisma.teacherAssignment.findFirst({
            where: { teacherId: teacher.id, classId, divisionId, subjectId, academicYearId }
        });
        if (exists) {
            return res.json({ success: true, data: exists, message: 'Already assigned' });
        }
        const a = await database_js_1.prisma.teacherAssignment.create({
            data: { teacherId: teacher.id, classId, divisionId, subjectId, academicYearId },
            include: { class: true, division: true, subject: true, academicYear: true }
        });
        res.json({ success: true, data: a });
    }
    catch (err) {
        next(err);
    }
});
// Admin-only teacher management routes
router.get('/', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const teachers = await database_js_1.prisma.teacher.findMany({
            include: { user: { select: { email: true, username: true, status: true } } }
        });
        res.json({ success: true, data: teachers });
    }
    catch (err) {
        next(err);
    }
});
router.get('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const t = await database_js_1.prisma.teacher.findUnique({
            where: { id: req.params.id },
            include: {
                user: true,
                assignments: { include: { class: true, division: true, subject: true, academicYear: true } }
            }
        });
        if (!t)
            return res.status(404).json({ success: false, error: 'Not found' });
        res.json({ success: true, data: t });
    }
    catch (err) {
        next(err);
    }
});
router.post('/', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { name, email, phone, username, password, qualification, department, photo } = req.body;
        const hash = await bcryptjs_1.default.hash(password, 10);
        const user = await database_js_1.prisma.user.create({
            data: {
                email, username, passwordHash: hash, role: 'FACULTY',
                teacher: {
                    create: { name, phone, qualification, department, photo: photo || null }
                }
            },
            include: { teacher: true }
        });
        res.json({ success: true, data: user.teacher });
    }
    catch (err) {
        next(err);
    }
});
router.put('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { name, phone, qualification, department, photo } = req.body;
        const t = await database_js_1.prisma.teacher.update({
            where: { id: req.params.id },
            data: {
                name,
                phone,
                qualification,
                department,
                photo: photo !== undefined ? photo : undefined,
            }
        });
        res.json({ success: true, data: t });
    }
    catch (err) {
        next(err);
    }
});
router.put('/:id/toggle-finalize', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const t = await database_js_1.prisma.teacher.findUnique({ where: { id: req.params.id } });
        const updated = await database_js_1.prisma.teacher.update({
            where: { id: req.params.id },
            data: { canFinalizeReportCards: !t?.canFinalizeReportCards }
        });
        res.json({ success: true, data: updated });
    }
    catch (err) {
        next(err);
    }
});
router.post('/:id/reset-password', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const t = await database_js_1.prisma.teacher.findUnique({ where: { id: req.params.id } });
        if (!t)
            return res.status(404).json({ success: false, error: 'Not found' });
        const hash = await bcryptjs_1.default.hash(req.body.newPassword, 10);
        await database_js_1.prisma.user.update({ where: { id: t.userId }, data: { passwordHash: hash } });
        res.json({ success: true, message: 'Password reset' });
    }
    catch (err) {
        next(err);
    }
});
router.delete('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const t = await database_js_1.prisma.teacher.findUnique({ where: { id: req.params.id } });
        if (t) {
            await database_js_1.prisma.user.update({ where: { id: t.userId }, data: { status: 'INACTIVE' } });
        }
        res.json({ success: true, message: 'Teacher deactivated' });
    }
    catch (err) {
        next(err);
    }
});
router.get('/:id/assignments', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const assignments = await database_js_1.prisma.teacherAssignment.findMany({
            where: { teacherId: req.params.id, academicYearId: String(req.query.academicYearId || '') },
            include: { class: true, division: true, subject: true }
        });
        res.json({ success: true, data: assignments });
    }
    catch (err) {
        next(err);
    }
});
router.post('/:id/assignments', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { classId, divisionId, subjectId, academicYearId } = req.body;
        const a = await database_js_1.prisma.teacherAssignment.create({
            data: { teacherId: req.params.id, classId, divisionId, subjectId, academicYearId }
        });
        res.json({ success: true, data: a });
    }
    catch (err) {
        next(err);
    }
});
router.delete('/assignments/:assignmentId', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        await database_js_1.prisma.teacherAssignment.delete({ where: { id: req.params.assignmentId } });
        res.json({ success: true, message: 'Assignment removed' });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
