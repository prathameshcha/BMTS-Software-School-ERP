"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const helpers_js_1 = require("../utils/helpers.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
router.use((0, roleGuard_js_1.authorize)('ADMIN'));
// Full dashboard stats — all from live DB queries
router.get('/dashboard', async (req, res, next) => {
    try {
        const { academicYearId } = req.query;
        // Get active academic year if not provided
        let ayId = String(academicYearId || '');
        if (!ayId) {
            const activeAy = await database_js_1.prisma.academicYear.findFirst({ where: { isActive: true } });
            ayId = activeAy?.id || '';
        }
        const [totalStudents, totalTeachers, totalClasses, totalDivisions,] = await Promise.all([
            database_js_1.prisma.student.count({ where: { status: 'ACTIVE' } }),
            database_js_1.prisma.teacher.count({ where: { user: { status: 'ACTIVE' } } }),
            database_js_1.prisma.class.count(),
            database_js_1.prisma.division.count(),
        ]);
        // Today's attendance
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const todayStr = today;
        const todayAttendance = await database_js_1.prisma.attendance.groupBy({
            by: ['status'],
            where: {
                date: todayStr,
                ...(ayId && { academicYearId: ayId }),
            },
            _count: { status: true },
        });
        const presentToday = todayAttendance.find(a => a.status === 'PRESENT')?._count?.status || 0;
        const absentToday = todayAttendance.find(a => a.status === 'ABSENT')?._count?.status || 0;
        const leaveToday = todayAttendance.find(a => a.status === 'LEAVE')?._count?.status || 0;
        // Pending marks: enrollments without any mark record in the active year
        const totalEnrollments = ayId
            ? await database_js_1.prisma.studentEnrollment.count({ where: { academicYearId: ayId } })
            : 0;
        const studentsWithMarks = ayId
            ? await database_js_1.prisma.mark.groupBy({
                by: ['studentId'],
                where: { academicYearId: ayId },
            })
            : [];
        const pendingMarks = Math.max(0, totalEnrollments - studentsWithMarks.length);
        // Completed report cards
        const completedReportCards = ayId
            ? await database_js_1.prisma.reportCard.count({
                where: { academicYearId: ayId, status: 'FINALIZED' },
            })
            : 0;
        const totalReportCards = ayId
            ? await database_js_1.prisma.reportCard.count({ where: { academicYearId: ayId } })
            : 0;
        // At-risk students: attendance < 75% OR avg marks < 40%
        // At-risk students: attendance < 75% OR avg marks < 75% (or bottom performers needing attention)
        let atRiskCount = 0;
        if (ayId) {
            const enrollments = await database_js_1.prisma.studentEnrollment.findMany({
                where: { academicYearId: ayId },
                include: { student: true },
            });
            // Total days attendance has actually been marked so far
            const distinctDatesCount = await database_js_1.prisma.attendance.groupBy({
                by: ['date'],
                where: { academicYearId: ayId },
            });
            const recordedDays = Math.max(distinctDatesCount.length, 5);
            for (const enroll of enrollments.slice(0, 200)) {
                const attCount = await database_js_1.prisma.attendance.count({
                    where: { studentId: enroll.studentId, academicYearId: ayId, status: 'PRESENT' },
                });
                const attPct = (0, helpers_js_1.computeAttendancePercentage)(attCount, recordedDays);
                const marks = await database_js_1.prisma.mark.findMany({
                    where: { studentId: enroll.studentId, academicYearId: ayId },
                    include: { subject: true },
                });
                let avgPct = 100;
                if (marks.length > 0) {
                    const totalObtained = marks.reduce((s, m) => s + (m.marksObtained || 0), 0);
                    const totalMax = marks.reduce((s, m) => s + m.subject.maxMarks, 0);
                    avgPct = totalMax > 0 ? (totalObtained / totalMax) * 100 : 100;
                }
                if (attPct < 75 || avgPct < 75) {
                    atRiskCount++;
                }
            }
        }
        // Average attendance across all students in active year
        let avgAttendance = 0;
        if (ayId) {
            const attendanceCounts = await database_js_1.prisma.attendance.groupBy({
                by: ['studentId'],
                where: { academicYearId: ayId, status: 'PRESENT' },
                _count: { status: true },
            });
            if (attendanceCounts.length > 0) {
                const academicYear = await database_js_1.prisma.academicYear.findUnique({ where: { id: ayId } });
                const holidays = academicYear
                    ? await database_js_1.prisma.holiday.findMany({ where: { academicYearId: ayId } })
                    : [];
                const holidayDates = holidays.map(h => h.date);
                const workingDays = academicYear
                    ? (0, helpers_js_1.computeWorkingDays)(academicYear.startDate, academicYear.endDate, holidayDates)
                    : 220;
                const totalPct = attendanceCounts.reduce((sum, a) => sum + (0, helpers_js_1.computeAttendancePercentage)(a._count.status, workingDays), 0);
                avgAttendance = Number((totalPct / attendanceCounts.length).toFixed(1));
            }
        }
        res.json({
            success: true,
            data: {
                totalStudents,
                totalTeachers,
                totalClasses,
                totalDivisions,
                presentToday,
                absentToday,
                leaveToday,
                pendingMarks,
                completedReportCards,
                totalReportCards,
                atRiskStudents: atRiskCount,
                avgAttendance,
            },
        });
    }
    catch (err) {
        next(err);
    }
});
// Attendance trends — last 30 days
router.get('/attendance-trends', async (req, res, next) => {
    try {
        const { academicYearId, days = '30', classId } = req.query;
        let ayId = String(academicYearId || '');
        if (!ayId) {
            const activeAy = await database_js_1.prisma.academicYear.findFirst({ where: { isActive: true } });
            ayId = activeAy?.id || '';
        }
        const endDate = new Date();
        endDate.setHours(23, 59, 59, 999);
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - Number(days));
        startDate.setHours(0, 0, 0, 0);
        const where = {
            date: { gte: startDate, lte: endDate },
            ...(ayId && { academicYearId: ayId }),
            ...(classId && { classId: String(classId) }),
        };
        const records = await database_js_1.prisma.attendance.groupBy({
            by: ['date', 'status'],
            where,
            _count: { status: true },
            orderBy: { date: 'asc' },
        });
        // Build date-indexed map
        const dateMap = {};
        for (const rec of records) {
            const dateKey = new Date(rec.date).toISOString().split('T')[0];
            if (!dateMap[dateKey]) {
                dateMap[dateKey] = { date: dateKey, present: 0, absent: 0, leave: 0 };
            }
            if (rec.status === 'PRESENT')
                dateMap[dateKey].present = rec._count.status;
            if (rec.status === 'ABSENT')
                dateMap[dateKey].absent = rec._count.status;
            if (rec.status === 'LEAVE')
                dateMap[dateKey].leave = rec._count.status;
        }
        res.json({ success: true, data: Object.values(dateMap) });
    }
    catch (err) {
        next(err);
    }
});
// Grade distribution — count of students per grade band for an exam/year
router.get('/grade-distribution', async (req, res, next) => {
    try {
        const { academicYearId, classId, examId } = req.query;
        let ayId = String(academicYearId || '');
        if (!ayId) {
            const activeAy = await database_js_1.prisma.academicYear.findFirst({ where: { isActive: true } });
            ayId = activeAy?.id || '';
        }
        const rules = await database_js_1.prisma.gradeRule.findMany({ orderBy: { minPercentage: 'desc' } });
        if (rules.length === 0) {
            return res.json({ success: true, data: [] });
        }
        // Aggregate per student
        const where = { ...(ayId && { academicYearId: ayId }) };
        if (classId)
            where.classId = String(classId);
        if (examId)
            where.examId = String(examId);
        const allMarks = await database_js_1.prisma.mark.findMany({
            where,
            include: { subject: true },
        });
        // Group by studentId, compute percentage, assign grade
        const studentMap = {};
        for (const m of allMarks) {
            if (!studentMap[m.studentId])
                studentMap[m.studentId] = { obtained: 0, max: 0 };
            studentMap[m.studentId].obtained += m.marksObtained || 0;
            studentMap[m.studentId].max += m.subject.maxMarks;
        }
        const gradeCounts = {};
        for (const [, val] of Object.entries(studentMap)) {
            const pct = val.max > 0 ? (val.obtained / val.max) * 100 : 0;
            const grade = (0, helpers_js_1.computeGrade)(pct, rules);
            gradeCounts[grade] = (gradeCounts[grade] || 0) + 1;
        }
        const data = Object.entries(gradeCounts).map(([grade, count]) => ({ grade, count }));
        res.json({ success: true, data });
    }
    catch (err) {
        next(err);
    }
});
// At-risk students — attendance < 75% OR marks < 40%
router.get('/at-risk', async (req, res, next) => {
    try {
        const { academicYearId, limit = '20' } = req.query;
        let ayId = String(academicYearId || '');
        if (!ayId) {
            const activeAy = await database_js_1.prisma.academicYear.findFirst({ where: { isActive: true } });
            ayId = activeAy?.id || '';
        }
        if (!ayId)
            return res.json({ success: true, data: [] });
        const distinctDates = await database_js_1.prisma.attendance.groupBy({
            by: ['date'],
            where: { academicYearId: ayId },
        });
        const recordedDays = Math.max(distinctDates.length, 5);
        const enrollments = await database_js_1.prisma.studentEnrollment.findMany({
            where: { academicYearId: ayId },
            include: {
                student: { select: { id: true, name: true, surname: true, admissionNo: true, rollNo: true, parentContact: true } },
                class: { select: { id: true, name: true } },
                division: { select: { id: true, name: true } },
            },
        });
        const candidates = [];
        for (const enroll of enrollments) {
            const presentCount = await database_js_1.prisma.attendance.count({
                where: { studentId: enroll.studentId, academicYearId: ayId, status: 'PRESENT' },
            });
            const attPct = (0, helpers_js_1.computeAttendancePercentage)(presentCount, recordedDays);
            const marks = await database_js_1.prisma.mark.findMany({
                where: { studentId: enroll.studentId, academicYearId: ayId },
                include: { subject: true },
            });
            let avgMarksPct = 100;
            let totalObtained = 0;
            let totalMax = 0;
            if (marks.length > 0) {
                totalObtained = marks.reduce((s, m) => s + (m.marksObtained || 0), 0);
                totalMax = marks.reduce((s, m) => s + m.subject.maxMarks, 0);
                avgMarksPct = totalMax > 0 ? (totalObtained / totalMax) * 100 : 100;
            }
            const reasons = [];
            if (attPct < 75)
                reasons.push(`Low attendance: ${attPct.toFixed(1)}%`);
            if (avgMarksPct < 75 && marks.length > 0)
                reasons.push(`Academic attention needed: ${avgMarksPct.toFixed(1)}%`);
            if (reasons.length === 0 && avgMarksPct < 80)
                reasons.push(`Needs improvement: ${avgMarksPct.toFixed(1)}%`);
            candidates.push({
                studentId: enroll.studentId,
                name: `${enroll.student.name} ${enroll.student.surname || ''}`.trim(),
                admissionNo: enroll.student.admissionNo,
                rollNo: enroll.student.rollNo,
                parentContact: enroll.student.parentContact,
                classId: enroll.class.id,
                divisionId: enroll.division.id,
                class: enroll.class.name,
                division: enroll.division.name,
                attendancePct: attPct,
                marksPct: Number(avgMarksPct.toFixed(1)),
                reasons: reasons.length > 0 ? reasons : ['Under review'],
            });
        }
        // Sort ascending by marks/attendance so lowest performers appear first
        candidates.sort((a, b) => a.marksPct - b.marksPct || a.attendancePct - b.attendancePct);
        const atRisk = candidates.slice(0, Number(limit) || 10);
        res.json({ success: true, data: atRisk });
    }
    catch (err) {
        next(err);
    }
});
// Top performing students
router.get('/toppers', async (req, res, next) => {
    try {
        const { academicYearId, examId, classId, limit = '10' } = req.query;
        let ayId = String(academicYearId || '');
        if (!ayId) {
            const activeAy = await database_js_1.prisma.academicYear.findFirst({ where: { isActive: true } });
            ayId = activeAy?.id || '';
        }
        const where = { ...(ayId && { academicYearId: ayId }) };
        if (examId)
            where.examId = String(examId);
        if (classId)
            where.classId = String(classId);
        const allMarks = await database_js_1.prisma.mark.findMany({
            where,
            include: {
                student: { select: { id: true, name: true, surname: true, rollNo: true, admissionNo: true } },
                subject: { select: { maxMarks: true } },
                class: { select: { id: true, name: true } },
                division: { select: { id: true, name: true } },
            },
        });
        const rules = await database_js_1.prisma.gradeRule.findMany({ orderBy: { minPercentage: 'desc' } });
        // Aggregate per student
        const studentMap = {};
        for (const m of allMarks) {
            if (!studentMap[m.studentId]) {
                studentMap[m.studentId] = {
                    name: `${m.student.name} ${m.student.surname || ''}`.trim(),
                    admissionNo: m.student.admissionNo,
                    rollNo: m.student.rollNo,
                    classId: m.class.id,
                    divisionId: m.division.id,
                    class: m.class.name,
                    division: m.division.name,
                    obtained: 0,
                    max: 0,
                };
            }
            studentMap[m.studentId].obtained += m.marksObtained || 0;
            studentMap[m.studentId].max += m.subject.maxMarks;
        }
        const sorted = Object.entries(studentMap)
            .map(([studentId, v]) => ({
            studentId,
            name: v.name,
            admissionNo: v.admissionNo,
            rollNo: v.rollNo,
            classId: v.classId,
            divisionId: v.divisionId,
            class: v.class,
            division: v.division,
            totalMarks: v.obtained,
            maxMarks: v.max,
            percentage: v.max > 0 ? Number(((v.obtained / v.max) * 100).toFixed(2)) : 0,
            grade: (0, helpers_js_1.computeGrade)(v.max > 0 ? (v.obtained / v.max) * 100 : 0, rules),
        }))
            .sort((a, b) => b.percentage - a.percentage)
            .slice(0, Number(limit))
            .map((s, i) => ({ ...s, rank: i + 1 }));
        res.json({ success: true, data: sorted });
    }
    catch (err) {
        next(err);
    }
});
// Class-wise student count
router.get('/class-distribution', async (req, res, next) => {
    try {
        const { academicYearId } = req.query;
        let ayId = String(academicYearId || '');
        if (!ayId) {
            const activeAy = await database_js_1.prisma.academicYear.findFirst({ where: { isActive: true } });
            ayId = activeAy?.id || '';
        }
        const classes = await database_js_1.prisma.class.findMany({ orderBy: { displayOrder: 'asc' } });
        const result = await Promise.all(classes.map(async (cls) => {
            const count = ayId
                ? await database_js_1.prisma.studentEnrollment.count({ where: { classId: cls.id, academicYearId: ayId } })
                : 0;
            return { classId: cls.id, class: cls.name, count };
        }));
        res.json({ success: true, data: result.filter(r => r.count > 0) });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
