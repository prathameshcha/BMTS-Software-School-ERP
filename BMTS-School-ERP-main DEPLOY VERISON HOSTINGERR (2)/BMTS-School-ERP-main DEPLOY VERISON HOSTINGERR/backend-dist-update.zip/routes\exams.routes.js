"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
router.use((0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'));
router.get('/', async (req, res, next) => {
    try {
        const { academicYearId, classId } = req.query;
        const where = {};
        if (academicYearId)
            where.academicYearId = String(academicYearId);
        if (classId)
            where.classId = String(classId);
        const exams = await database_js_1.prisma.exam.findMany({ where, include: { class: true, division: true } });
        res.json({ success: true, data: exams });
    }
    catch (err) {
        next(err);
    }
});
router.post('/', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { name, academicYearId, classId, divisionId, startDate, endDate } = req.body;
        const ex = await database_js_1.prisma.exam.create({
            data: { name, academicYearId, classId, divisionId, startDate: startDate ? new Date(startDate) : null, endDate: endDate ? new Date(endDate) : null }
        });
        res.json({ success: true, data: ex });
    }
    catch (err) {
        next(err);
    }
});
router.put('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { name, startDate, endDate, isActive } = req.body;
        const ex = await database_js_1.prisma.exam.update({
            where: { id: req.params.id },
            data: { name, isActive, startDate: startDate ? new Date(startDate) : null, endDate: endDate ? new Date(endDate) : null }
        });
        res.json({ success: true, data: ex });
    }
    catch (err) {
        next(err);
    }
});
router.delete('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        await database_js_1.prisma.exam.delete({ where: { id: req.params.id } });
        res.json({ success: true, message: 'Deleted' });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
