"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const helpers_js_1 = require("../utils/helpers.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
router.get('/me', (0, roleGuard_js_1.authorize)('STUDENT', 'ADMIN'), async (req, res, next) => {
    try {
        const student = await database_js_1.prisma.student.findUnique({
            where: { userId: req.user?.id },
            include: { user: true, enrollments: { include: { class: true, division: true, academicYear: true } } }
        });
        if (!student)
            return res.status(404).json({ success: false, error: 'Student profile not found' });
        res.json({ success: true, data: student });
    }
    catch (err) {
        next(err);
    }
});
router.get('/', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const { classId, divisionId, academicYearId } = req.query;
        let studentIds;
        if (classId || divisionId || academicYearId) {
            const enrollments = await database_js_1.prisma.studentEnrollment.findMany({
                where: {
                    ...(classId && { classId: String(classId) }),
                    ...(divisionId && { divisionId: String(divisionId) }),
                    ...(academicYearId && { academicYearId: String(academicYearId) })
                },
                select: { studentId: true }
            });
            studentIds = enrollments.map(e => e.studentId);
        }
        const whereClause = studentIds ? { id: { in: studentIds } } : {};
        let requireActive = true;
        if (academicYearId) {
            const targetYear = await database_js_1.prisma.academicYear.findUnique({ where: { id: String(academicYearId) } });
            if (targetYear && !targetYear.isActive) {
                requireActive = false;
            }
        }
        if (requireActive) {
            whereClause.status = 'ACTIVE';
        }
        const students = await database_js_1.prisma.student.findMany({
            where: whereClause,
            include: { user: { select: { email: true, username: true } }, enrollments: { include: { class: true, division: true } } }
        });
        res.json({ success: true, data: students });
    }
    catch (err) {
        next(err);
    }
});
router.get('/:id', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const s = await database_js_1.prisma.student.findUnique({
            where: { id: req.params.id },
            include: { user: true, enrollments: { include: { class: true, division: true, academicYear: true } } }
        });
        if (!s)
            return res.status(404).json({ success: false, error: 'Not found' });
        res.json({ success: true, data: s });
    }
    catch (err) {
        next(err);
    }
});
router.post('/', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { name, surname, admissionNo, rollNo, dob, age, gender, photo, motherTongue, fatherName, fatherOccupation, motherName, motherOccupation, parentContact, parentEmail, address, aadharNo, birthPlace, penNo, bloodGroup, height, weight } = req.body;
        const fullName = surname ? `${name.trim()} ${surname.trim()}` : name.trim();
        const creds = (0, helpers_js_1.generateCredentials)(fullName);
        const hash = await bcryptjs_1.default.hash(creds.passwordHash, 10);
        const user = await database_js_1.prisma.user.create({
            data: {
                email: parentEmail || `${creds.username}@student.mtfschool.edu`,
                username: creds.username,
                passwordHash: hash,
                role: 'STUDENT',
                student: {
                    create: {
                        name: fullName,
                        surname: surname ? surname.trim() : null,
                        admissionNo,
                        rollNo,
                        dob: dob ? new Date(dob) : null,
                        age: age ? Number(age) : null,
                        gender: gender || null,
                        photo: photo || null,
                        motherTongue: motherTongue || null,
                        fatherName: fatherName || null,
                        fatherOccupation: fatherOccupation || null,
                        motherName: motherName || null,
                        motherOccupation: motherOccupation || null,
                        parentContact: parentContact || null,
                        parentEmail: parentEmail || null,
                        address: address || null,
                        aadharNo: aadharNo || null,
                        birthPlace: birthPlace || null,
                        penNo: penNo || null,
                        bloodGroup: bloodGroup || null,
                        height: height ? String(height) : null,
                        weight: weight ? String(weight) : null,
                    }
                }
            },
            include: { student: true }
        });
        res.json({ success: true, data: user.student, credentials: { username: creds.username, password: creds.passwordHash } });
    }
    catch (err) {
        next(err);
    }
});
router.put('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { name, surname, rollNo, dob, age, gender, photo, motherTongue, fatherName, fatherOccupation, motherName, motherOccupation, parentContact, parentEmail, address, aadharNo, birthPlace, penNo, bloodGroup, height, weight } = req.body;
        const s = await database_js_1.prisma.student.update({
            where: { id: req.params.id },
            data: {
                name: name ? name.trim() : undefined,
                surname: surname !== undefined ? (surname ? surname.trim() : null) : undefined,
                rollNo,
                dob: dob ? new Date(dob) : null,
                age: age !== undefined ? (age ? Number(age) : null) : undefined,
                gender: gender || null,
                photo: photo !== undefined ? photo : undefined,
                motherTongue: motherTongue !== undefined ? motherTongue : undefined,
                fatherName: fatherName !== undefined ? fatherName : undefined,
                fatherOccupation: fatherOccupation !== undefined ? fatherOccupation : undefined,
                motherName: motherName !== undefined ? motherName : undefined,
                motherOccupation: motherOccupation !== undefined ? motherOccupation : undefined,
                parentContact: parentContact !== undefined ? parentContact : undefined,
                parentEmail: parentEmail !== undefined ? parentEmail : undefined,
                address: address !== undefined ? address : undefined,
                aadharNo: aadharNo !== undefined ? aadharNo : undefined,
                birthPlace: birthPlace !== undefined ? birthPlace : undefined,
                penNo: penNo !== undefined ? penNo : undefined,
                bloodGroup: bloodGroup !== undefined ? bloodGroup : undefined,
                height: height !== undefined ? (height ? String(height) : null) : undefined,
                weight: weight !== undefined ? (weight ? String(weight) : null) : undefined,
            }
        });
        res.json({ success: true, data: s });
    }
    catch (err) {
        next(err);
    }
});
router.delete('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        await database_js_1.prisma.student.update({ where: { id: req.params.id }, data: { status: 'ARCHIVED' } });
        const s = await database_js_1.prisma.student.findUnique({ where: { id: req.params.id } });
        if (s)
            await database_js_1.prisma.user.update({ where: { id: s.userId }, data: { status: 'INACTIVE' } });
        res.json({ success: true, message: 'Student archived' });
    }
    catch (err) {
        next(err);
    }
});
router.post('/:id/enroll', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { classId, divisionId, academicYearId, rollNo } = req.body;
        const e = await database_js_1.prisma.studentEnrollment.create({
            data: { studentId: req.params.id, classId, divisionId, academicYearId, rollNo }
        });
        res.json({ success: true, data: e });
    }
    catch (err) {
        next(err);
    }
});
router.post('/promote', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { studentIds, targetClassId, targetDivisionId, targetAcademicYearId, rollNumbers } = req.body;
        if (!Array.isArray(studentIds) || studentIds.length === 0) {
            return res.status(400).json({ success: false, error: 'studentIds must be a non-empty array' });
        }
        if (!targetClassId || !targetDivisionId || !targetAcademicYearId) {
            return res.status(400).json({
                success: false,
                error: 'targetClassId, targetDivisionId and targetAcademicYearId are required',
            });
        }
        // A student may only have one enrollment per academic year. Students
        // already enrolled in the target year are filtered out explicitly instead
        // of using `skipDuplicates` (which becomes INSERT IGNORE on MySQL and would
        // also mask foreign-key errors), so the caller gets an accurate count.
        const existing = await database_js_1.prisma.studentEnrollment.findMany({
            where: { academicYearId: targetAcademicYearId, studentId: { in: studentIds } },
            select: { studentId: true },
        });
        const alreadyEnrolled = new Set(existing.map((e) => e.studentId));
        const toPromote = studentIds.filter((id) => !alreadyEnrolled.has(id));
        const creates = toPromote.map((id) => ({
            studentId: id,
            classId: targetClassId,
            divisionId: targetDivisionId,
            academicYearId: targetAcademicYearId,
            rollNo: rollNumbers && rollNumbers[id] !== undefined ? String(rollNumbers[id]) : null,
            status: 'ENROLLED',
        }));
        if (creates.length > 0) {
            await database_js_1.prisma.studentEnrollment.createMany({ data: creates });
        }
        res.json({
            success: true,
            data: {
                promoted: creates.length,
                skipped: alreadyEnrolled.size,
                promotedIds: toPromote,
                skippedIds: Array.from(alreadyEnrolled)
            },
        });
    }
    catch (err) {
        next(err);
    }
});
router.post('/promote-all', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { sourceAcademicYearId, targetAcademicYearId } = req.body;
        if (!sourceAcademicYearId || !targetAcademicYearId) {
            return res.status(400).json({ success: false, error: 'sourceAcademicYearId and targetAcademicYearId are required' });
        }
        if (sourceAcademicYearId === targetAcademicYearId) {
            return res.status(400).json({ success: false, error: 'Source and target years cannot be the same' });
        }
        const allClasses = await database_js_1.prisma.class.findMany({ orderBy: { displayOrder: 'asc' } });
        const nextClassMap = new Map();
        for (let i = 0; i < allClasses.length - 1; i++) {
            nextClassMap.set(allClasses[i].id, allClasses[i + 1].id);
        }
        const allDivisions = await database_js_1.prisma.division.findMany();
        const sourceEnrollments = await database_js_1.prisma.studentEnrollment.findMany({
            where: {
                academicYearId: sourceAcademicYearId,
                student: { status: 'ACTIVE' }
            },
            include: { division: true }
        });
        const existingTargetEnrollments = await database_js_1.prisma.studentEnrollment.findMany({
            where: { academicYearId: targetAcademicYearId },
            select: { studentId: true }
        });
        const alreadyEnrolled = new Set(existingTargetEnrollments.map(e => e.studentId));
        let promotedCount = 0;
        let graduatedCount = 0;
        let missingDivisionCount = 0;
        const creates = [];
        for (const enrollment of sourceEnrollments) {
            if (alreadyEnrolled.has(enrollment.studentId))
                continue;
            const nextClassId = nextClassMap.get(enrollment.classId);
            if (!nextClassId) {
                graduatedCount++;
                continue;
            }
            const targetDivision = allDivisions.find(d => d.classId === nextClassId && d.name === enrollment.division.name);
            if (!targetDivision) {
                missingDivisionCount++;
                continue;
            }
            creates.push({
                studentId: enrollment.studentId,
                classId: nextClassId,
                divisionId: targetDivision.id,
                academicYearId: targetAcademicYearId,
                rollNo: enrollment.rollNo,
                status: 'ENROLLED'
            });
        }
        if (creates.length > 0) {
            await database_js_1.prisma.studentEnrollment.createMany({ data: creates });
            promotedCount = creates.length;
        }
        res.json({
            success: true,
            data: {
                promoted: promotedCount,
                skipped: alreadyEnrolled.size,
                graduated: graduatedCount,
                missingDivision: missingDivisionCount
            }
        });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
