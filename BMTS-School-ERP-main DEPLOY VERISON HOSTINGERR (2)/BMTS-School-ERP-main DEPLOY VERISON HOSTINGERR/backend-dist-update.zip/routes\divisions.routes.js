"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
router.get('/', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY', 'STUDENT'), async (req, res, next) => {
    try {
        const { classId } = req.query;
        const where = classId ? { classId: String(classId) } : {};
        const divisions = await database_js_1.prisma.division.findMany({ where, orderBy: { name: 'asc' } });
        res.json({ success: true, data: divisions });
    }
    catch (err) {
        next(err);
    }
});
router.post('/', async (req, res, next) => {
    try {
        const { name, classId } = req.body;
        const div = await database_js_1.prisma.division.create({ data: { name, classId } });
        res.json({ success: true, data: div });
    }
    catch (err) {
        next(err);
    }
});
router.put('/:id', async (req, res, next) => {
    try {
        const { name, classId } = req.body;
        const div = await database_js_1.prisma.division.update({
            where: { id: req.params.id },
            data: { name, classId }
        });
        res.json({ success: true, data: div });
    }
    catch (err) {
        next(err);
    }
});
router.delete('/:id', async (req, res, next) => {
    try {
        await database_js_1.prisma.division.delete({ where: { id: req.params.id } });
        res.json({ success: true, message: 'Deleted' });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
