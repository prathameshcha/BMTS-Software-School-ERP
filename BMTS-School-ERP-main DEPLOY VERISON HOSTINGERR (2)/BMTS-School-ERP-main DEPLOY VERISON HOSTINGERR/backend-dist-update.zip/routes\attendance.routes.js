"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const helpers_js_1 = require("../utils/helpers.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
// Get attendance for a class/division/date (for marking/editing)
router.get('/', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const { classId, divisionId, date, academicYearId } = req.query;
        const where = {};
        if (classId)
            where.classId = String(classId);
        if (divisionId)
            where.divisionId = String(divisionId);
        if (academicYearId)
            where.academicYearId = String(academicYearId);
        if (date)
            where.date = new Date(String(date));
        const att = await database_js_1.prisma.attendance.findMany({
            where,
            include: {
                student: { select: { id: true, name: true, rollNo: true, admissionNo: true } },
                markedBy: { select: { name: true } },
            },
            orderBy: [{ student: { rollNo: 'asc' } }],
        });
        res.json({ success: true, data: att });
    }
    catch (err) {
        next(err);
    }
});
// Bulk save/upsert attendance for a class/date
router.post('/', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const records = Array.isArray(req.body) ? req.body : (req.body.records || []);
        if (!records || records.length === 0) {
            return res.status(400).json({ success: false, error: 'No attendance records provided' });
        }
        // Check if attendance is OFF by Admin for FACULTY
        if (req.user?.role === 'FACULTY') {
            const settings = await database_js_1.prisma.schoolSettings.findFirst();
            const isAllowed = settings && settings.motto && settings.motto.includes('AUTO_ATTENDANCE:ON');
            if (!isAllowed) {
                return res.status(403).json({
                    success: false,
                    error: 'admin had off the attendence please contact admin',
                    attendanceDisabled: true
                });
            }
        }
        const teacher = await database_js_1.prisma.teacher.findFirst({ where: { userId: req.user?.id } });
        const markedById = teacher?.id || null;
        // Active academic year fallback
        let defaultYearId = req.body.academicYearId;
        if (!defaultYearId) {
            const activeAy = await database_js_1.prisma.academicYear.findFirst({ where: { isActive: true } });
            defaultYearId = activeAy?.id;
        }
        const defaultDateStr = req.body.date || new Date().toISOString().split('T')[0];
        let finalMarkedById = teacher?.id;
        if (!finalMarkedById) {
            const anyTeacher = await database_js_1.prisma.teacher.findFirst();
            finalMarkedById = anyTeacher?.id || '';
        }
        for (const r of records) {
            const dateVal = new Date(r.date || defaultDateStr);
            const ayId = r.academicYearId || defaultYearId;
            const cId = r.classId || req.body.classId;
            const dId = r.divisionId || req.body.divisionId;
            if (!r.studentId || isNaN(dateVal.getTime()) || !ayId || !cId || !dId || !finalMarkedById) {
                continue;
            }
            await database_js_1.prisma.attendance.upsert({
                where: {
                    studentId_date_academicYearId: {
                        studentId: r.studentId,
                        date: dateVal,
                        academicYearId: ayId,
                    },
                },
                update: {
                    status: r.status || 'PRESENT',
                    markedById: finalMarkedById,
                },
                create: {
                    studentId: r.studentId,
                    classId: cId,
                    divisionId: dId,
                    academicYearId: ayId,
                    date: dateVal,
                    status: r.status || 'PRESENT',
                    markedById: finalMarkedById,
                },
            });
        }
        res.json({ success: true, message: 'Attendance saved successfully' });
    }
    catch (err) {
        next(err);
    }
});
// Per-student attendance stats
router.get('/student/:studentId', async (req, res, next) => {
    try {
        const { academicYearId } = req.query;
        // Without this guard a missing param became findUnique({ id: "undefined" }),
        // which answered 404 "Academic year not found" and sent callers hunting for
        // a missing record instead of a missing query parameter.
        if (!academicYearId) {
            return res.status(400).json({ success: false, error: 'academicYearId is required' });
        }
        const ay = await database_js_1.prisma.academicYear.findUnique({ where: { id: String(academicYearId) } });
        if (!ay)
            return res.status(404).json({ success: false, error: 'Academic year not found' });
        const holidays = await database_js_1.prisma.holiday.findMany({ where: { academicYearId: ay.id } });
        const holidayDates = holidays.map(h => h.date);
        const workingDays = (0, helpers_js_1.computeWorkingDays)(ay.startDate, ay.endDate, holidayDates);
        const atts = await database_js_1.prisma.attendance.findMany({
            where: { studentId: req.params.studentId, academicYearId: ay.id },
            orderBy: { date: 'asc' },
        });
        const presentDays = atts.filter(a => a.status === 'PRESENT').length;
        const absentDays = atts.filter(a => a.status === 'ABSENT').length;
        const leaveDays = atts.filter(a => a.status === 'LEAVE').length;
        const pct = (0, helpers_js_1.computeAttendancePercentage)(presentDays, workingDays);
        res.json({
            success: true,
            data: {
                history: atts,
                stats: {
                    workingDays,
                    presentDays,
                    absentDays,
                    leaveDays,
                    percentage: pct,
                    academicYear: ay.name,
                    startDate: ay.startDate,
                    endDate: ay.endDate,
                },
            },
        });
    }
    catch (err) {
        next(err);
    }
});
// Class-level attendance report: per student — workingDays, present, absent, leave, %
router.get('/report', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const { classId, divisionId, academicYearId, month } = req.query;
        if (!classId || !divisionId || !academicYearId) {
            return res.status(400).json({ success: false, error: 'classId, divisionId, academicYearId are required' });
        }
        const ay = await database_js_1.prisma.academicYear.findUnique({ where: { id: String(academicYearId) } });
        if (!ay)
            return res.status(404).json({ success: false, error: 'Academic year not found' });
        const holidays = await database_js_1.prisma.holiday.findMany({ where: { academicYearId: String(academicYearId) } });
        const holidayDates = holidays.map(h => h.date);
        // If month filter provided, compute working days for that month only
        let startDate = ay.startDate;
        let endDate = ay.endDate;
        if (month) {
            const [year, monthNum] = String(month).split('-').map(Number);
            startDate = new Date(year, monthNum - 1, 1);
            endDate = new Date(year, monthNum, 0, 23, 59, 59);
        }
        const workingDays = (0, helpers_js_1.computeWorkingDays)(startDate, endDate, holidayDates);
        const enrollments = await database_js_1.prisma.studentEnrollment.findMany({
            where: { classId: String(classId), divisionId: String(divisionId), academicYearId: String(academicYearId) },
            include: { student: { select: { id: true, name: true, rollNo: true, admissionNo: true } } },
        });
        const results = await Promise.all(enrollments.map(async (enroll) => {
            const attWhere = {
                studentId: enroll.studentId,
                academicYearId: String(academicYearId),
                date: { gte: startDate, lte: endDate },
            };
            const atts = await database_js_1.prisma.attendance.findMany({ where: attWhere });
            const presentDays = atts.filter(a => a.status === 'PRESENT').length;
            const absentDays = atts.filter(a => a.status === 'ABSENT').length;
            const leaveDays = atts.filter(a => a.status === 'LEAVE').length;
            const percentage = (0, helpers_js_1.computeAttendancePercentage)(presentDays, workingDays);
            return {
                studentId: enroll.studentId,
                name: enroll.student.name,
                admissionNo: enroll.student.admissionNo,
                rollNo: enroll.student.rollNo || enroll.rollNo,
                workingDays,
                presentDays,
                absentDays,
                leaveDays,
                percentage,
                isAtRisk: percentage < 75,
            };
        }));
        results.sort((a, b) => (a.rollNo || '').localeCompare(b.rollNo || '', undefined, { numeric: true }));
        res.json({ success: true, data: results, workingDays });
    }
    catch (err) {
        next(err);
    }
});
// Today's attendance summary across all classes
router.get('/today-summary', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { academicYearId } = req.query;
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const where = { date: today };
        if (academicYearId)
            where.academicYearId = String(academicYearId);
        const grouped = await database_js_1.prisma.attendance.groupBy({
            by: ['classId', 'status'],
            where,
            _count: { status: true },
        });
        const classes = await database_js_1.prisma.class.findMany({ orderBy: { displayOrder: 'asc' } });
        const result = classes.map(cls => {
            const clsData = grouped.filter(g => g.classId === cls.id);
            return {
                class: cls.name,
                classId: cls.id,
                present: clsData.find(d => d.status === 'PRESENT')?._count?.status || 0,
                absent: clsData.find(d => d.status === 'ABSENT')?._count?.status || 0,
                leave: clsData.find(d => d.status === 'LEAVE')?._count?.status || 0,
            };
        });
        res.json({ success: true, data: result.filter(r => r.present + r.absent + r.leave > 0) });
    }
    catch (err) {
        next(err);
    }
});
// GET auto-attendance toggle state from SchoolSettings
router.get('/auto-mode', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const settings = await database_js_1.prisma.schoolSettings.findFirst();
        let enabled = false;
        if (settings && settings.motto && settings.motto.includes('AUTO_ATTENDANCE:ON')) {
            enabled = true;
        }
        res.json({ success: true, enabled });
    }
    catch (err) {
        next(err);
    }
});
// PUT auto-attendance toggle state (ADMIN only)
router.put('/auto-mode', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { enabled } = req.body;
        let settings = await database_js_1.prisma.schoolSettings.findFirst();
        if (!settings) {
            settings = await database_js_1.prisma.schoolSettings.create({
                data: {
                    schoolName: 'Bharat Ratna Mother Teresa English School',
                    motto: enabled ? 'AUTO_ATTENDANCE:ON' : 'AUTO_ATTENDANCE:OFF',
                }
            });
        }
        else {
            let currentMotto = settings.motto || '';
            currentMotto = currentMotto.replace(/AUTO_ATTENDANCE:(ON|OFF)/g, '').trim();
            const updatedMotto = `${currentMotto} ${enabled ? 'AUTO_ATTENDANCE:ON' : 'AUTO_ATTENDANCE:OFF'}`.trim();
            settings = await database_js_1.prisma.schoolSettings.update({
                where: { id: settings.id },
                data: { motto: updatedMotto }
            });
        }
        res.json({
            success: true,
            enabled: !!enabled,
            message: enabled ? 'Automatic All-Student Attendance mode is now ACTIVE' : 'Automatic Attendance mode is now DISABLED'
        });
    }
    catch (err) {
        next(err);
    }
});
// POST Mark Attendance for ALL students across ALL classes & divisions for a given date
router.post('/mark-all-students', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { date, academicYearId, status = 'PRESENT', overwrite = false } = req.body;
        let ayId = academicYearId;
        if (!ayId) {
            const activeAy = await database_js_1.prisma.academicYear.findFirst({ where: { isActive: true } });
            ayId = activeAy?.id;
        }
        if (!ayId) {
            return res.status(400).json({ success: false, error: 'No active academic year found' });
        }
        const dateVal = date ? new Date(date) : new Date();
        dateVal.setHours(0, 0, 0, 0);
        // Get any active teacher to mark by
        const teacher = await database_js_1.prisma.teacher.findFirst();
        const markedById = teacher?.id || '';
        // Fetch all active enrollments in this academic year
        const enrollments = await database_js_1.prisma.studentEnrollment.findMany({
            where: { academicYearId: ayId },
            include: {
                student: { select: { id: true, name: true, status: true } },
            },
        });
        const activeEnrollments = enrollments.filter(e => e.student.status === 'ACTIVE');
        if (activeEnrollments.length === 0) {
            return res.status(400).json({ success: false, error: 'No active students enrolled' });
        }
        let markedCount = 0;
        let skippedCount = 0;
        for (const enroll of activeEnrollments) {
            if (!overwrite) {
                const existing = await database_js_1.prisma.attendance.findUnique({
                    where: {
                        studentId_date_academicYearId: {
                            studentId: enroll.studentId,
                            date: dateVal,
                            academicYearId: ayId,
                        },
                    },
                });
                if (existing) {
                    skippedCount++;
                    continue;
                }
            }
            await database_js_1.prisma.attendance.upsert({
                where: {
                    studentId_date_academicYearId: {
                        studentId: enroll.studentId,
                        date: dateVal,
                        academicYearId: ayId,
                    },
                },
                update: {
                    status: status,
                    markedById,
                },
                create: {
                    studentId: enroll.studentId,
                    classId: enroll.classId,
                    divisionId: enroll.divisionId,
                    academicYearId: ayId,
                    date: dateVal,
                    status: status,
                    markedById,
                },
            });
            markedCount++;
        }
        res.json({
            success: true,
            message: `Attendance for ${dateVal.toISOString().split('T')[0]} marked as '${status}' for ${markedCount} students! (${skippedCount} already recorded)`,
            data: {
                totalStudents: activeEnrollments.length,
                markedCount,
                skippedCount,
                date: dateVal.toISOString().split('T')[0],
            },
        });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
