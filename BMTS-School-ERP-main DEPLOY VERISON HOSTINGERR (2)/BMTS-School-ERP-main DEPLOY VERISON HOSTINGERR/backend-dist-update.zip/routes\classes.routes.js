"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
router.get('/', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const classes = await database_js_1.prisma.class.findMany({
            include: {
                divisions: {
                    include: {
                        _count: { select: { enrollments: true } }
                    },
                    orderBy: { name: 'asc' }
                },
                subjects: {
                    select: { id: true, name: true, maxMarks: true },
                    orderBy: { displayOrder: 'asc' }
                },
                _count: {
                    select: { enrollments: true, subjects: true }
                }
            },
            orderBy: { displayOrder: 'asc' }
        });
        res.json({ success: true, data: classes });
    }
    catch (err) {
        next(err);
    }
});
router.get('/:id', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const c = await database_js_1.prisma.class.findUnique({
            where: { id: req.params.id },
            include: {
                divisions: {
                    include: {
                        enrollments: {
                            include: {
                                student: {
                                    select: {
                                        id: true,
                                        name: true,
                                        surname: true,
                                        admissionNo: true,
                                        rollNo: true,
                                        gender: true,
                                        parentContact: true,
                                        bloodGroup: true,
                                        photo: true,
                                        status: true,
                                    }
                                }
                            },
                            orderBy: { rollNo: 'asc' }
                        },
                        assignments: {
                            include: {
                                teacher: {
                                    include: {
                                        user: { select: { email: true, username: true } }
                                    }
                                },
                                subject: {
                                    select: { id: true, name: true, code: true }
                                }
                            }
                        },
                        _count: {
                            select: { enrollments: true, marks: true, reportCards: true }
                        }
                    },
                    orderBy: { name: 'asc' }
                },
                subjects: {
                    select: { id: true, name: true, code: true, maxMarks: true, passingMarks: true, displayOrder: true },
                    orderBy: { displayOrder: 'asc' }
                },
                _count: {
                    select: { enrollments: true, subjects: true, exams: true }
                }
            }
        });
        if (!c)
            return res.status(404).json({ success: false, error: 'Not found' });
        res.json({ success: true, data: c });
    }
    catch (err) {
        next(err);
    }
});
router.post('/', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { name, displayOrder, reportCardTemplate } = req.body;
        const c = await database_js_1.prisma.class.create({
            data: { name, displayOrder, reportCardTemplate }
        });
        res.json({ success: true, data: c });
    }
    catch (err) {
        next(err);
    }
});
router.put('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { name, displayOrder, reportCardTemplate } = req.body;
        const c = await database_js_1.prisma.class.update({
            where: { id: req.params.id },
            data: { name, displayOrder, reportCardTemplate }
        });
        res.json({ success: true, data: c });
    }
    catch (err) {
        next(err);
    }
});
router.delete('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        await database_js_1.prisma.class.delete({ where: { id: req.params.id } });
        res.json({ success: true, message: 'Deleted successfully' });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
