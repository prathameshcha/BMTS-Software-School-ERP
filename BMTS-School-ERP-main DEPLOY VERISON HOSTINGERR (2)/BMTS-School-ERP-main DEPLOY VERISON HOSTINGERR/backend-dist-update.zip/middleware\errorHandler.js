"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorHandler = void 0;
const errorHandler = (err, req, res, next) => {
    // Always log the full error server-side so pm2 logs show the real cause
    console.error(`[${req.method} ${req.path}] Error:`, {
        message: err.message,
        code: err.code,
        meta: err.meta,
        stack: err.stack,
    });
    const status = err.status || 500;
    const isProduction = process.env.NODE_ENV === 'production';
    const message = isProduction && status === 500
        ? 'Internal Server Error'
        : err.message || 'Internal Server Error';
    res.status(status).json({
        success: false,
        error: message,
        ...(isProduction ? {} : { stack: err.stack }),
    });
};
exports.errorHandler = errorHandler;
