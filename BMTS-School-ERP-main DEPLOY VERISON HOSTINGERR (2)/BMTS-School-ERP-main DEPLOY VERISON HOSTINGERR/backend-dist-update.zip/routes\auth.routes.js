"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const database_js_1 = require("../config/database.js");
const jwt_js_1 = require("../config/jwt.js");
const auth_js_1 = require("../middleware/auth.js");
const router = (0, express_1.Router)();
const REFRESH_COOKIE = 'refreshToken';
const REFRESH_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000; // 7 days
/**
 * Options for the refresh-token cookie.
 *
 * `sameSite` was hard-coded to 'strict', which breaks the refresh flow the
 * moment the API is served from a different site than the SPA. It is now
 * configurable: keep the default 'lax' for the single-origin deploy, and set
 * COOKIE_SAMESITE=none (which forces Secure, as browsers require) when the API
 * really is cross-site.
 *
 * `secure` follows NODE_ENV but can be overridden with COOKIE_SECURE, because a
 * production box terminating TLS elsewhere — or one still on plain HTTP — would
 * otherwise set a cookie the browser refuses to send back, making every
 * refresh fail.
 *
 * clearCookie() must be given the same attributes it was set with, or the
 * browser keeps the original cookie and logout does not actually log out.
 */
const sameSite = (process.env.COOKIE_SAMESITE || 'lax').toLowerCase();
const secureCookie = process.env.COOKIE_SECURE !== undefined
    ? process.env.COOKIE_SECURE === 'true'
    : process.env.NODE_ENV === 'production';
const refreshCookieOptions = {
    httpOnly: true,
    sameSite,
    // SameSite=None is only honoured on secure cookies.
    secure: sameSite === 'none' ? true : secureCookie,
    path: '/',
};
router.post('/login', async (req, res, next) => {
    try {
        const rawLogin = req.body.login || req.body.username || req.body.email;
        const password = req.body.password;
        if (!rawLogin || !password) {
            return res.status(400).json({ success: false, error: 'Login and password are required' });
        }
        const login = String(rawLogin).trim().toLowerCase();
        // Accept either the email address or the username as the login identifier.
        // Students are issued a username equal to their admission number (e.g.
        // "adm001"), and the Profile page presents that username as their
        // "Login ID" — so matching on email alone locked every student out.
        // Emails and usernames are stored lowercase, and `login` is lowercased
        // above, which keeps this case-insensitive on any database.
        const user = await database_js_1.prisma.user.findFirst({
            where: {
                OR: [{ email: login }, { username: login }],
            },
            include: {
                teacher: true,
                admin: true,
                student: true,
            }
        });
        if (!user || user.status !== 'ACTIVE') {
            return res.status(401).json({ success: false, error: 'Invalid credentials or inactive account' });
        }
        const isValid = await bcryptjs_1.default.compare(password, user.passwordHash);
        if (!isValid) {
            return res.status(401).json({ success: false, error: 'Invalid credentials' });
        }
        const payload = { id: user.id, role: user.role, email: user.email };
        const accessToken = jsonwebtoken_1.default.sign(payload, jwt_js_1.JWT_SECRET, { expiresIn: jwt_js_1.JWT_EXPIRY });
        const refreshToken = jsonwebtoken_1.default.sign(payload, jwt_js_1.JWT_REFRESH_SECRET, { expiresIn: jwt_js_1.JWT_REFRESH_EXPIRY });
        res.cookie(REFRESH_COOKIE, refreshToken, {
            ...refreshCookieOptions,
            maxAge: REFRESH_MAX_AGE_MS,
        });
        // The admin/teacher/student relations are already loaded above, so surface
        // the human-readable name and the profile id here. The client showed the
        // raw username ("adm001") everywhere because the login response never
        // returned a name to fall back from.
        const profile = user.admin ?? user.teacher ?? user.student ?? null;
        res.json({
            success: true,
            data: {
                token: accessToken,
                accessToken,
                user: {
                    id: user.id,
                    email: user.email,
                    username: user.username,
                    role: user.role,
                    name: profile?.name ?? user.username,
                    profileId: profile?.id ?? null,
                }
            }
        });
    }
    catch (error) {
        next(error);
    }
});
router.post('/refresh', async (req, res, next) => {
    try {
        const refreshToken = req.cookies?.[REFRESH_COOKIE];
        if (!refreshToken)
            return res.status(401).json({ success: false, error: 'No refresh token' });
        let decoded;
        try {
            decoded = jsonwebtoken_1.default.verify(refreshToken, jwt_js_1.JWT_REFRESH_SECRET);
        }
        catch {
            // 401, not 403: an expired or tampered refresh token means the session is
            // over and the client should fall back to the login screen. 403 would
            // tell the client the session is fine but the action is forbidden.
            res.clearCookie(REFRESH_COOKIE, refreshCookieOptions);
            return res.status(401).json({ success: false, error: 'Invalid or expired refresh token' });
        }
        // Re-read the user so a deactivated or deleted account cannot keep minting
        // access tokens for the remaining 7 days of its refresh token, and so a
        // role change takes effect on the next refresh rather than the next login.
        const user = await database_js_1.prisma.user.findUnique({
            where: { id: decoded.id },
            select: { id: true, email: true, role: true, status: true },
        });
        if (!user || user.status !== 'ACTIVE') {
            res.clearCookie(REFRESH_COOKIE, refreshCookieOptions);
            return res.status(401).json({ success: false, error: 'Account is no longer active' });
        }
        const payload = { id: user.id, role: user.role, email: user.email };
        const accessToken = jsonwebtoken_1.default.sign(payload, jwt_js_1.JWT_SECRET, { expiresIn: jwt_js_1.JWT_EXPIRY });
        res.json({
            success: true,
            data: {
                accessToken,
                token: accessToken,
                user: { id: user.id, email: user.email, role: user.role },
            },
        });
    }
    catch (error) {
        next(error);
    }
});
router.post('/logout', (_req, res) => {
    // Same attributes as the cookie was set with, otherwise the browser ignores
    // the clear and the refresh token survives logout.
    res.clearCookie(REFRESH_COOKIE, refreshCookieOptions);
    res.json({ success: true, message: 'Logged out successfully' });
});
router.get('/me', auth_js_1.authenticateToken, async (req, res, next) => {
    try {
        const user = await database_js_1.prisma.user.findUnique({
            where: { id: req.user.id },
            include: {
                admin: true,
                teacher: true,
                student: true
            }
        });
        if (!user)
            return res.status(404).json({ success: false, error: 'User not found' });
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { passwordHash, ...safeUser } = user;
        res.json({ success: true, data: safeUser });
    }
    catch (error) {
        next(error);
    }
});
router.put('/profile', auth_js_1.authenticateToken, async (req, res, next) => {
    try {
        const userId = req.user?.id;
        if (!userId)
            return res.status(401).json({ success: false, error: 'Unauthorized' });
        const { email, password } = req.body;
        const updateData = {};
        if (email) {
            const emailTrim = String(email).trim().toLowerCase();
            // Check if email already taken
            const existing = await database_js_1.prisma.user.findFirst({
                where: {
                    email: emailTrim,
                    NOT: { id: userId }
                }
            });
            if (existing) {
                return res.status(400).json({ success: false, error: 'Email address is already in use by another account' });
            }
            updateData.email = emailTrim;
        }
        if (password) {
            if (String(password).trim().length < 6) {
                return res.status(400).json({ success: false, error: 'Password must be at least 6 characters long' });
            }
            updateData.passwordHash = await bcryptjs_1.default.hash(password, 10);
        }
        if (Object.keys(updateData).length === 0) {
            return res.status(400).json({ success: false, error: 'No fields provided for update' });
        }
        const user = await database_js_1.prisma.user.update({
            where: { id: userId },
            data: updateData,
            include: {
                admin: true,
                teacher: true,
                student: true
            }
        });
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { passwordHash, ...safeUser } = user;
        res.json({ success: true, message: 'Profile updated successfully', data: safeUser });
    }
    catch (error) {
        next(error);
    }
});
exports.default = router;
