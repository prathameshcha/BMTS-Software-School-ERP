"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// src/routes/cron.routes.ts
const express_1 = require("express");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const attendanceAutoGenerate_js_1 = require("../cron/attendanceAutoGenerate.js");
const enums_js_1 = require("../types/enums.js");
const router = (0, express_1.Router)();
router.get('/run-attendance', (0, roleGuard_js_1.authorize)(enums_js_1.UserRole.ADMIN), async (req, res) => {
    try {
        await (0, attendanceAutoGenerate_js_1.runAutoAttendanceNow)();
        res.json({ success: true, message: 'Auto-attendance executed' });
    }
    catch (error) {
        console.error('Manual attendance run error:', error);
        res.status(500).json({ success: false, error: 'Failed to run attendance' });
    }
});
exports.default = router;
