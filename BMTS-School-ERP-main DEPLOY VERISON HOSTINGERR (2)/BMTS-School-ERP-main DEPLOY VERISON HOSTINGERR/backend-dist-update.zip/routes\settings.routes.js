"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
router.get('/', async (req, res, next) => {
    try {
        let settings = await database_js_1.prisma.schoolSettings.findFirst();
        if (!settings) {
            settings = await database_js_1.prisma.schoolSettings.create({
                data: {
                    schoolName: 'Bharat Ratna Mother Teresa English School',
                    address: 'Gangapur Dist. Chha. Sambhajinagar - 431109',
                    phone: '+91 9876543210',
                    email: 'contact@mtfschool.edu',
                    motto: 'Education for Excellence',
                    principalName: 'Dr. S. K. Sharma',
                }
            });
        }
        else if (settings.schoolName !== 'Bharat Ratna Mother Teresa English School') {
            settings = await database_js_1.prisma.schoolSettings.update({
                where: { id: settings.id },
                data: {
                    schoolName: 'Bharat Ratna Mother Teresa English School',
                    address: 'Gangapur Dist. Chha. Sambhajinagar - 431109',
                }
            });
        }
        res.json({ success: true, data: settings });
    }
    catch (err) {
        next(err);
    }
});
router.put('/', auth_js_1.authenticateToken, (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const settings = await database_js_1.prisma.schoolSettings.findFirst();
        const updated = await database_js_1.prisma.schoolSettings.update({
            where: { id: settings.id },
            data: req.body
        });
        res.json({ success: true, data: updated });
    }
    catch (err) {
        next(err);
    }
});
router.post('/logo', auth_js_1.authenticateToken, (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    res.json({ success: true, message: 'Logo uploaded' });
});
exports.default = router;
