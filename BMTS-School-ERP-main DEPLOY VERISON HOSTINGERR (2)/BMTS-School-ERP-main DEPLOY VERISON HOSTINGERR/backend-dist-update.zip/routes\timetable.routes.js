"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
router.get('/', async (req, res, next) => {
    try {
        const { classId, divisionId, academicYearId } = req.query;
        const tt = await database_js_1.prisma.timetable.findMany({
            where: { classId: String(classId), divisionId: String(divisionId), academicYearId: String(academicYearId) }
        });
        res.json({ success: true, data: tt });
    }
    catch (err) {
        next(err);
    }
});
router.post('/', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const records = req.body.records;
        for (const r of records) {
            await database_js_1.prisma.timetable.upsert({
                where: {
                    classId_divisionId_academicYearId_dayOfWeek_periodNumber: {
                        classId: r.classId, divisionId: r.divisionId, academicYearId: r.academicYearId,
                        dayOfWeek: r.dayOfWeek, periodNumber: r.periodNumber
                    }
                },
                update: { subjectId: r.subjectId, teacherId: r.teacherId, room: r.room },
                create: r
            });
        }
        res.json({ success: true, message: 'Timetable saved' });
    }
    catch (err) {
        next(err);
    }
});
router.put('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const tt = await database_js_1.prisma.timetable.update({ where: { id: req.params.id }, data: req.body });
        res.json({ success: true, data: tt });
    }
    catch (err) {
        next(err);
    }
});
router.delete('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        await database_js_1.prisma.timetable.delete({ where: { id: req.params.id } });
        res.json({ success: true, message: 'Deleted' });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
