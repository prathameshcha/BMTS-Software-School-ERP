"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authenticateToken = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const jwt_js_1 = require("../config/jwt.js");
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const [scheme, token] = (authHeader || '').split(' ');
    if (!token || !/^Bearer$/i.test(scheme)) {
        return res.status(401).json({ success: false, error: 'Access token missing' });
    }
    jsonwebtoken_1.default.verify(token, jwt_js_1.JWT_SECRET, (err, user) => {
        if (err) {
            // 401, not 403.
            //
            // Access tokens live 15 minutes, so expiry is the normal case, not an
            // error. The client's axios interceptor silently refreshes on 401 and
            // retries — it does not (and per RFC 7235 should not) refresh on 403,
            // which means "authenticated but not permitted". Answering 403 here made
            // every request fail hard 15 minutes after login with no refresh
            // attempted, so the whole app appeared to log the user out at random.
            const expired = err.name === 'TokenExpiredError';
            return res.status(401).json({
                success: false,
                error: expired ? 'Access token expired' : 'Invalid access token',
                code: expired ? 'TOKEN_EXPIRED' : 'TOKEN_INVALID',
            });
        }
        req.user = user;
        next();
    });
};
exports.authenticateToken = authenticateToken;
