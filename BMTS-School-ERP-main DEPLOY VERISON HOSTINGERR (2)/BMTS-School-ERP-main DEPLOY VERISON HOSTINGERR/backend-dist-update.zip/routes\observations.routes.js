"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
// GET  /api/observations?studentId=&classId=&divisionId=
// Returns all observations for a student or a class
router.get('/', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const { studentId, classId, divisionId } = req.query;
        const where = {};
        if (studentId)
            where.studentId = String(studentId);
        if (classId || divisionId) {
            // Filter by students enrolled in this class/div (latest enrollment)
            const enrollments = await database_js_1.prisma.studentEnrollment.findMany({
                where: {
                    ...(classId && { classId: String(classId) }),
                    ...(divisionId && { divisionId: String(divisionId) }),
                },
                select: { studentId: true },
            });
            const ids = enrollments.map((e) => e.studentId);
            where.studentId = { in: ids };
        }
        const observations = await database_js_1.prisma.studentObservation.findMany({
            where,
            include: {
                student: { select: { id: true, name: true, rollNo: true, admissionNo: true, photo: true } },
                teacher: { select: { id: true, name: true } },
            },
            orderBy: { date: 'desc' },
        });
        res.json({ success: true, data: observations });
    }
    catch (err) {
        next(err);
    }
});
// POST /api/observations  — teacher adds remark
router.post('/', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const { studentId, remark, category, date } = req.body;
        if (!studentId || !remark) {
            return res.status(400).json({ success: false, error: 'studentId and remark are required' });
        }
        // Resolve teacherId from logged-in user
        const teacher = await database_js_1.prisma.teacher.findUnique({ where: { userId: req.user?.id } });
        if (!teacher && req.user?.role !== 'ADMIN') {
            return res.status(403).json({ success: false, error: 'Teacher profile not found' });
        }
        // Admins without a teacher profile use a sentinel; find any teacher or skip
        let teacherId = teacher?.id;
        if (!teacherId) {
            // Admin: try to find first teacher as fallback (or create observation with admin marker)
            const anyTeacher = await database_js_1.prisma.teacher.findFirst();
            if (!anyTeacher)
                return res.status(400).json({ success: false, error: 'No teacher profile found' });
            teacherId = anyTeacher.id;
        }
        const obs = await database_js_1.prisma.studentObservation.create({
            data: {
                studentId,
                teacherId,
                remark: remark.trim(),
                category: category || 'GENERAL',
                date: date ? new Date(date) : new Date(),
            },
            include: {
                student: { select: { id: true, name: true, rollNo: true, admissionNo: true } },
                teacher: { select: { id: true, name: true } },
            },
        });
        res.json({ success: true, data: obs });
    }
    catch (err) {
        next(err);
    }
});
// PUT /api/observations/:id  — update remark
router.put('/:id', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const { remark, category } = req.body;
        const existing = await database_js_1.prisma.studentObservation.findUnique({ where: { id: req.params.id } });
        if (!existing)
            return res.status(404).json({ success: false, error: 'Observation not found' });
        // Faculty can only edit their own remarks
        if (req.user?.role === 'FACULTY') {
            const teacher = await database_js_1.prisma.teacher.findUnique({ where: { userId: req.user.id } });
            if (!teacher || existing.teacherId !== teacher.id) {
                return res.status(403).json({ success: false, error: 'You can only edit your own remarks' });
            }
        }
        const updated = await database_js_1.prisma.studentObservation.update({
            where: { id: req.params.id },
            data: {
                ...(remark && { remark: remark.trim() }),
                ...(category && { category }),
            },
            include: {
                student: { select: { id: true, name: true, rollNo: true, admissionNo: true } },
                teacher: { select: { id: true, name: true } },
            },
        });
        res.json({ success: true, data: updated });
    }
    catch (err) {
        next(err);
    }
});
// DELETE /api/observations/:id
router.delete('/:id', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const existing = await database_js_1.prisma.studentObservation.findUnique({ where: { id: req.params.id } });
        if (!existing)
            return res.status(404).json({ success: false, error: 'Observation not found' });
        if (req.user?.role === 'FACULTY') {
            const teacher = await database_js_1.prisma.teacher.findUnique({ where: { userId: req.user.id } });
            if (!teacher || existing.teacherId !== teacher.id) {
                return res.status(403).json({ success: false, error: 'You can only delete your own remarks' });
            }
        }
        await database_js_1.prisma.studentObservation.delete({ where: { id: req.params.id } });
        res.json({ success: true, message: 'Observation deleted' });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
