"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const cookie_parser_1 = __importDefault(require("cookie-parser"));
const dotenv_1 = __importDefault(require("dotenv"));
const helmet_1 = __importDefault(require("helmet"));
const compression_1 = __importDefault(require("compression"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const errorHandler_js_1 = require("./middleware/errorHandler.js");
const database_js_1 = require("./config/database.js");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const auth_routes_js_1 = __importDefault(require("./routes/auth.routes.js"));
const academicYears_routes_js_1 = __importDefault(require("./routes/academicYears.routes.js"));
const classes_routes_js_1 = __importDefault(require("./routes/classes.routes.js"));
const divisions_routes_js_1 = __importDefault(require("./routes/divisions.routes.js"));
const subjects_routes_js_1 = __importDefault(require("./routes/subjects.routes.js"));
const export_routes_js_1 = __importDefault(require("./routes/export.routes.js"));
const cron_routes_js_1 = __importDefault(require("./routes/cron.routes.js"));
const attendanceAutoGenerate_js_1 = require("./cron/attendanceAutoGenerate.js");
const exams_routes_js_1 = __importDefault(require("./routes/exams.routes.js"));
const marks_routes_js_1 = __importDefault(require("./routes/marks.routes.js"));
const gradeRules_routes_js_1 = __importDefault(require("./routes/gradeRules.routes.js"));
const reportCards_routes_js_1 = __importDefault(require("./routes/reportCards.routes.js"));
const homework_routes_js_1 = __importDefault(require("./routes/homework.routes.js"));
const teachers_routes_js_1 = __importDefault(require("./routes/teachers.routes.js"));
const students_routes_js_1 = __importDefault(require("./routes/students.routes.js"));
const attendance_routes_js_1 = __importDefault(require("./routes/attendance.routes.js"));
const notices_routes_js_1 = __importDefault(require("./routes/notices.routes.js"));
const notifications_routes_js_1 = __importDefault(require("./routes/notifications.routes.js"));
const timetable_routes_js_1 = __importDefault(require("./routes/timetable.routes.js"));
const holidays_routes_js_1 = __importDefault(require("./routes/holidays.routes.js"));
const settings_routes_js_1 = __importDefault(require("./routes/settings.routes.js"));
const analytics_routes_js_1 = __importDefault(require("./routes/analytics.routes.js"));
const auditLogs_routes_js_1 = __importDefault(require("./routes/auditLogs.routes.js"));
const certificates_routes_js_1 = __importDefault(require("./routes/certificates.routes.js"));
const remarkBank_routes_js_1 = __importDefault(require("./routes/remarkBank.routes.js"));
const pdf_routes_js_1 = __importDefault(require("./routes/pdf.routes.js"));
const teachingLogs_routes_js_1 = __importDefault(require("./routes/teachingLogs.routes.js"));
const observations_routes_js_1 = __importDefault(require("./routes/observations.routes.js"));
const admins_routes_js_1 = __importDefault(require("./routes/admins.routes.js"));
dotenv_1.default.config();
const app = (0, express_1.default)();
const isProduction = process.env.NODE_ENV === 'production';
// Behind a reverse proxy (Nginx, Hostinger, any PaaS) every request arrives
// from the proxy, so req.ip was the proxy's address for all traffic and the
// rate limiter counted the entire school as one client — the whole site would
// start returning 429 and logins looked broken. Trusting one proxy hop makes
// req.ip the real client address from X-Forwarded-For.
// Set TRUST_PROXY=false if the app is exposed directly with no proxy.
if (process.env.TRUST_PROXY !== 'false') {
    app.set('trust proxy', Number(process.env.TRUST_PROXY) || 1);
}
// Security headers
app.use((0, helmet_1.default)({
    contentSecurityPolicy: false, // Disable CSP for flexibility; configure per deployment
}));
// Compression
app.use((0, compression_1.default)());
// General API rate limiting. Raised well above the old 500: a single logged-in
// dashboard fires a dozen requests per page, so a staffroom sharing one public
// IP exhausted a 500/15min budget in minutes.
const limiter = (0, express_rate_limit_1.default)({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: Number(process.env.RATE_LIMIT_MAX) || (isProduction ? 3000 : 20000),
    standardHeaders: true,
    legacyHeaders: false,
    message: { success: false, error: 'Too many requests, please try again later.' },
});
// Brute-force protection for login, keyed by IP *and* submitted identifier.
// Keying on IP alone would lock out an entire school behind one NAT address the
// moment a few people fat-fingered a password; keying in the identifier too
// limits guessing against any single account without that collateral damage.
const loginLimiter = (0, express_rate_limit_1.default)({
    windowMs: 15 * 60 * 1000,
    max: Number(process.env.LOGIN_RATE_LIMIT_MAX) || 30,
    standardHeaders: true,
    legacyHeaders: false,
    skipSuccessfulRequests: true, // only failed attempts count
    keyGenerator: (req) => {
        const id = String(req.body?.login || req.body?.username || req.body?.email || '')
            .trim()
            .toLowerCase();
        return `${req.ip}|${id}`;
    },
    message: {
        success: false,
        error: 'Too many failed login attempts. Please wait 15 minutes and try again.',
    },
});
// CORS — allow any localhost origin in dev, use FRONTEND_URL in prod
const allowedOrigins = [
    process.env.FRONTEND_URL || 'http://localhost:5173',
    'http://localhost:5173',
    'http://localhost:5174',
    'http://localhost:5175',
    'http://localhost:4173',
    'http://127.0.0.1:5173',
    'http://127.0.0.1:5174',
];
app.use((0, cors_1.default)({
    origin: (origin, callback) => {
        // Allow requests with no origin (mobile apps, curl, Postman)
        if (!origin)
            return callback(null, true);
        if (allowedOrigins.includes(origin))
            return callback(null, true);
        // Allow any localhost / 127.0.0.1 origin in development
        if (!isProduction && /^http:\/\/(localhost|127\.0\.0\.1):\d+$/.test(origin)) {
            return callback(null, true);
        }
        // Tag the rejection as 403. A bare Error reached the error handler with no
        // status and was reported as 500 Internal Server Error, which reads like the
        // server is broken when in fact FRONTEND_URL simply does not match the
        // browser's origin — the single most common deployment mistake here.
        const err = new Error(`CORS: origin ${origin} is not allowed. Set FRONTEND_URL to this exact origin.`);
        err.status = 403;
        callback(err);
    },
    credentials: true,
}));
// Body parsing
app.use(express_1.default.json({ limit: '10mb' }));
app.use(express_1.default.urlencoded({ extended: true }));
app.use((0, cookie_parser_1.default)());
// Static uploads
app.use('/uploads', express_1.default.static(path_1.default.join(process.cwd(), 'uploads')));
// Health check
app.get('/api/health', (_req, res) => {
    res.json({
        success: true,
        status: 'ok',
        timestamp: new Date().toISOString(),
        environment: process.env.NODE_ENV || 'development',
    });
});
// Database connectivity check — temporary debug endpoint.
// DELETE THIS after the database issue is resolved.
app.get('/api/debug/db-check', async (_req, res) => {
    try {
        const result = await database_js_1.prisma.$queryRaw `SELECT 1 as ok`;
        const userCount = await database_js_1.prisma.user.count();
        res.json({
            success: true,
            database: 'connected',
            rawQuery: result,
            userCount,
            databaseUrl: process.env.DATABASE_URL?.replace(/:[^:@]+@/, ':***@'),
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            database: 'FAILED',
            error: error.message,
            code: error.code,
            databaseUrl: process.env.DATABASE_URL?.replace(/:[^:@]+@/, ':***@'),
        });
    }
});
app.use('/api/', limiter);
// Mounted after express.json() so the limiter's keyGenerator can read the
// submitted identifier from req.body, and before the auth router so it runs first.
app.use('/api/auth/login', loginLimiter);
// Mount routes
app.use('/api/auth', auth_routes_js_1.default);
app.use('/api/admins', admins_routes_js_1.default);
app.use('/api/academic-years', academicYears_routes_js_1.default);
app.use('/api/classes', classes_routes_js_1.default);
app.use('/api/divisions', divisions_routes_js_1.default);
app.use('/api/subjects', subjects_routes_js_1.default);
app.use('/api/teachers', teachers_routes_js_1.default);
app.use('/api/students', students_routes_js_1.default);
app.use('/api/attendance', attendance_routes_js_1.default);
app.use('/api/exams', exams_routes_js_1.default);
app.use('/api/marks', marks_routes_js_1.default);
app.use('/api/grade-rules', gradeRules_routes_js_1.default);
app.use('/api/report-cards', reportCards_routes_js_1.default);
app.use('/api/homework', homework_routes_js_1.default);
app.use('/api/notices', notices_routes_js_1.default);
app.use('/api/notifications', notifications_routes_js_1.default);
app.use('/api/timetable', timetable_routes_js_1.default);
app.use('/api/holidays', holidays_routes_js_1.default);
app.use('/api/settings', settings_routes_js_1.default);
app.use('/api/analytics', analytics_routes_js_1.default);
app.use('/api/audit-logs', auditLogs_routes_js_1.default);
app.use('/api/certificates', certificates_routes_js_1.default);
app.use('/api/remark-bank', remarkBank_routes_js_1.default);
app.use('/api/pdf', pdf_routes_js_1.default);
app.use('/api/teaching-logs', teachingLogs_routes_js_1.default);
app.use('/api/observations', observations_routes_js_1.default);
app.use('/api/export', export_routes_js_1.default);
app.use('/api/cron', cron_routes_js_1.default);
// Unknown /api paths must answer with JSON. Without this they fell through to
// the SPA fallback below and returned index.html with a 200, so a typo'd or
// renamed endpoint surfaced in the browser as an opaque JSON parse error
// instead of a 404.
app.use('/api', (_req, res) => {
    res.status(404).json({ success: false, error: 'API endpoint not found' });
});
// In production, serve the frontend build if no reverse proxy (Nginx) is present.
// Checks ../public_html (deploy_ready layout) then ../frontend/dist (monorepo).
if (isProduction) {
    const candidates = [
        path_1.default.join(process.cwd(), '..', 'public_html'),
        path_1.default.join(process.cwd(), '..', 'frontend', 'dist'),
        path_1.default.join(process.cwd(), 'public_html'),
        path_1.default.join(process.cwd(), 'frontend', 'dist'),
    ];
    const frontendPath = candidates.find((p) => fs_1.default.existsSync(path_1.default.join(p, 'index.html')));
    if (frontendPath) {
        app.use(express_1.default.static(frontendPath, {
            // Hashed asset filenames are safe to cache hard; index.html must not be,
            // or a deploy leaves browsers on the previous bundle indefinitely.
            setHeaders: (res, filePath) => {
                if (filePath.endsWith('index.html')) {
                    res.setHeader('Cache-Control', 'no-cache, must-revalidate');
                }
            },
            maxAge: '1y',
        }));
        // SPA fallback — every non-API route serves index.html so deep links and
        // page refreshes on /admin, /faculty, /student resolve client-side.
        app.get('*', (_req, res) => {
            res.sendFile(path_1.default.join(frontendPath, 'index.html'));
        });
        console.log(`[prod] Serving frontend from ${frontendPath}`);
    }
    else {
        console.warn('[prod] No frontend build found. Checked:\n  ' + candidates.join('\n  '));
    }
}
// Error handler LAST. Express only routes to error middleware that is
// registered after the handlers it should cover; mounting it before the static
// and SPA handlers left their failures unhandled.
app.use(errorHandler_js_1.errorHandler);
// Start server
const PORT = process.env.PORT || 3000;
const server = app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT} [${process.env.NODE_ENV || 'development'}]`);
    (0, attendanceAutoGenerate_js_1.scheduleAttendanceAutoGeneration)();
});
// Graceful shutdown
const gracefulShutdown = async (signal) => {
    console.log(`\n${signal} received. Shutting down gracefully...`);
    server.close(async () => {
        console.log('HTTP server closed.');
        await database_js_1.prisma.$disconnect();
        console.log('Database connection closed.');
        process.exit(0);
    });
    // Force shutdown after 30 seconds
    setTimeout(() => {
        console.error('Could not close connections in time, forcefully shutting down.');
        process.exit(1);
    }, 30000);
};
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
