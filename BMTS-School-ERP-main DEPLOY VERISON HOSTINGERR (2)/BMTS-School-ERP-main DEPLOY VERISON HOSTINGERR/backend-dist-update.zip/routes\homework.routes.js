"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
router.get('/', async (req, res, next) => {
    try {
        const { classId, divisionId } = req.query;
        const hw = await database_js_1.prisma.homework.findMany({
            where: { classId: String(classId), divisionId: String(divisionId) },
            include: { subject: true }
        });
        res.json({ success: true, data: hw });
    }
    catch (err) {
        next(err);
    }
});
router.post('/', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const t = await database_js_1.prisma.teacher.findFirst({ where: { userId: req.user.id } });
        const hw = await database_js_1.prisma.homework.create({
            data: { ...req.body, teacherId: t?.id || req.body.teacherId }
        });
        res.json({ success: true, data: hw });
    }
    catch (err) {
        next(err);
    }
});
router.put('/:id', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const hw = await database_js_1.prisma.homework.update({ where: { id: req.params.id }, data: req.body });
        res.json({ success: true, data: hw });
    }
    catch (err) {
        next(err);
    }
});
router.delete('/:id', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        await database_js_1.prisma.homework.delete({ where: { id: req.params.id } });
        res.json({ success: true, message: 'Deleted' });
    }
    catch (err) {
        next(err);
    }
});
router.post('/:id/submit', async (req, res, next) => {
    try {
        const s = await database_js_1.prisma.student.findFirst({ where: { userId: req.user.id } });
        if (!s)
            return res.status(403).json({ success: false, error: 'Only students can submit' });
        const sub = await database_js_1.prisma.homeworkSubmission.create({
            data: { homeworkId: req.params.id, studentId: s.id, filePath: req.body.filePath, status: 'SUBMITTED' }
        });
        res.json({ success: true, data: sub });
    }
    catch (err) {
        next(err);
    }
});
router.put('/submissions/:id/review', (0, roleGuard_js_1.authorize)('ADMIN', 'FACULTY'), async (req, res, next) => {
    try {
        const sub = await database_js_1.prisma.homeworkSubmission.update({
            where: { id: req.params.id },
            data: { status: 'REVIEWED', grade: req.body.grade, feedback: req.body.feedback }
        });
        res.json({ success: true, data: sub });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
