"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
router.get('/', async (req, res, next) => {
    try {
        const n = await database_js_1.prisma.notification.findMany({
            where: { userId: req.user.id },
            orderBy: { createdAt: 'desc' }
        });
        res.json({ success: true, data: n });
    }
    catch (err) {
        next(err);
    }
});
router.put('/:id/read', async (req, res, next) => {
    try {
        await database_js_1.prisma.notification.update({
            where: { id: req.params.id },
            data: { isRead: true }
        });
        res.json({ success: true, message: 'Marked as read' });
    }
    catch (err) {
        next(err);
    }
});
router.put('/read-all', async (req, res, next) => {
    try {
        await database_js_1.prisma.notification.updateMany({
            where: { userId: req.user.id, isRead: false },
            data: { isRead: true }
        });
        res.json({ success: true, message: 'All marked as read' });
    }
    catch (err) {
        next(err);
    }
});
router.get('/unread-count', async (req, res, next) => {
    try {
        const count = await database_js_1.prisma.notification.count({
            where: { userId: req.user.id, isRead: false }
        });
        res.json({ success: true, data: { count } });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
