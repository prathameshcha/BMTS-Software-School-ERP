"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const roleGuard_js_1 = require("../middleware/roleGuard.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
// Academic years are reference data that every role needs in order to scope
// their own views: the student Marks / Attendance / Report Card pages each load
// the year list alongside their profile. A router-wide ADMIN guard used to make
// those requests 403, which rejected the pages' Promise.all and left the whole
// student portal blank. Reads are therefore open to any authenticated user,
// while every mutation stays admin-only.
router.get('/', async (req, res, next) => {
    try {
        const { active } = req.query;
        const where = active === 'true' ? { isActive: true } : {};
        const years = await database_js_1.prisma.academicYear.findMany({ where, orderBy: { startDate: 'desc' } });
        res.json({ success: true, data: years });
    }
    catch (err) {
        next(err);
    }
});
router.get('/:id', async (req, res, next) => {
    try {
        const year = await database_js_1.prisma.academicYear.findUnique({ where: { id: req.params.id } });
        if (!year)
            return res.status(404).json({ success: false, error: 'Not found' });
        res.json({ success: true, data: year });
    }
    catch (err) {
        next(err);
    }
});
router.post('/', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { name, startDate, endDate, isActive } = req.body;
        if (isActive) {
            await database_js_1.prisma.academicYear.updateMany({ data: { isActive: false } });
        }
        const count = await database_js_1.prisma.academicYear.count();
        const shouldBeActive = isActive || count === 0;
        const newYear = await database_js_1.prisma.academicYear.create({
            data: {
                name: name.trim(),
                startDate: new Date(startDate),
                endDate: new Date(endDate),
                isActive: shouldBeActive,
            }
        });
        res.json({ success: true, data: newYear });
    }
    catch (err) {
        next(err);
    }
});
router.put('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const { name, startDate, endDate, isActive } = req.body;
        if (isActive) {
            await database_js_1.prisma.academicYear.updateMany({ data: { isActive: false } });
        }
        const updated = await database_js_1.prisma.academicYear.update({
            where: { id: req.params.id },
            data: {
                ...(name && { name: name.trim() }),
                ...(startDate && { startDate: new Date(startDate) }),
                ...(endDate && { endDate: new Date(endDate) }),
                ...(isActive !== undefined && { isActive: Boolean(isActive) }),
            }
        });
        res.json({ success: true, data: updated });
    }
    catch (err) {
        next(err);
    }
});
// Activate Academic Year (Sets as active across the entire ERP)
const activateHandler = async (req, res, next) => {
    try {
        const id = req.params.id;
        const target = await database_js_1.prisma.academicYear.findUnique({ where: { id } });
        if (!target)
            return res.status(404).json({ success: false, error: 'Academic year not found' });
        await database_js_1.prisma.$transaction([
            database_js_1.prisma.academicYear.updateMany({ data: { isActive: false } }),
            database_js_1.prisma.academicYear.update({ where: { id }, data: { isActive: true } })
        ]);
        res.json({ success: true, message: `Academic Year ${target.name} is now active across the entire ERP system.`, data: { ...target, isActive: true } });
    }
    catch (err) {
        next(err);
    }
};
router.put('/:id/activate', (0, roleGuard_js_1.authorize)('ADMIN'), activateHandler);
router.patch('/:id/activate', (0, roleGuard_js_1.authorize)('ADMIN'), activateHandler);
router.delete('/:id', (0, roleGuard_js_1.authorize)('ADMIN'), async (req, res, next) => {
    try {
        const target = await database_js_1.prisma.academicYear.findUnique({ where: { id: req.params.id } });
        if (!target)
            return res.status(404).json({ success: false, error: 'Academic year not found' });
        const count = await database_js_1.prisma.academicYear.count();
        if (count <= 1) {
            return res.status(400).json({ success: false, error: 'Cannot delete the only academic year in the system.' });
        }
        // Cascade / clean references if any
        const fallbackYear = await database_js_1.prisma.academicYear.findFirst({ where: { id: { not: target.id } } });
        if (fallbackYear) {
            if (target.isActive) {
                await database_js_1.prisma.academicYear.update({ where: { id: fallbackYear.id }, data: { isActive: true } });
            }
            await database_js_1.prisma.studentEnrollment.updateMany({ where: { academicYearId: target.id }, data: { academicYearId: fallbackYear.id } });
            await database_js_1.prisma.teacherAssignment.updateMany({ where: { academicYearId: target.id }, data: { academicYearId: fallbackYear.id } });
            await database_js_1.prisma.attendance.updateMany({ where: { academicYearId: target.id }, data: { academicYearId: fallbackYear.id } });
            await database_js_1.prisma.exam.updateMany({ where: { academicYearId: target.id }, data: { academicYearId: fallbackYear.id } });
            await database_js_1.prisma.mark.updateMany({ where: { academicYearId: target.id }, data: { academicYearId: fallbackYear.id } });
            await database_js_1.prisma.reportCard.updateMany({ where: { academicYearId: target.id }, data: { academicYearId: fallbackYear.id } });
        }
        await database_js_1.prisma.academicYear.delete({ where: { id: req.params.id } });
        res.json({ success: true, message: `Academic Year ${target.name} deleted successfully` });
    }
    catch (err) {
        next(err);
    }
});
exports.default = router;
