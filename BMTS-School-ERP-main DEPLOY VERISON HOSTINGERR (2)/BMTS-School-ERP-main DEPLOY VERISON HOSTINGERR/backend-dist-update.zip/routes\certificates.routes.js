"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_js_1 = require("../config/database.js");
const auth_js_1 = require("../middleware/auth.js");
const router = (0, express_1.Router)();
router.use(auth_js_1.authenticateToken);
router.get('/', async (req, res, next) => {
    try {
        const c = await database_js_1.prisma.certificate.findMany({
            where: { studentId: String(req.query.studentId) }
        });
        res.json({ success: true, data: c });
    }
    catch (err) {
        next(err);
    }
});
router.post('/', async (req, res, next) => {
    try {
        const c = await database_js_1.prisma.certificate.create({ data: req.body });
        res.json({ success: true, data: c });
    }
    catch (err) {
        next(err);
    }
});
router.get('/:id/pdf', async (req, res, next) => {
    res.json({ success: true, message: 'PDF generated' });
});
exports.default = router;
